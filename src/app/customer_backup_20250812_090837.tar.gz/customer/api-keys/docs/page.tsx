'use client'

import { useState } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  Text,
  Alert,
  Tabs,
  Code,
  Badge,
  Accordion,
  Divider,
  Center,
  LoadingOverlay,
  ActionIcon,
  Modal,
  TextInput,
  Select
} from '@mantine/core'
import { useDisclosure } from '@mantine/hooks'
import { useForm } from '@mantine/form'
import { notifications } from '@mantine/notifications'
import {
  IconBook,
  IconCode,
  IconServer,
  IconKey,
  IconExternalLink,
  IconCopy,
  IconCheck,
  IconPlaylistAdd,
  IconApi,
  IconInfoCircle,
  IconWorld,
  IconRefresh
} from '@tabler/icons-react'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface SwaggerSpec {
  openapi: string
  info: {
    title: string
    version: string
    description: string
  }
  servers: Array<{
    url: string
    description: string
  }>
  paths: Record<string, any>
}

interface ApiTestForm {
  endpoint: string
  method: string
  apiKey: string
  body: string
}

export default function CustomerApiDocsPage() {
  const [swaggerSpec, setSwaggerSpec] = useState<SwaggerSpec | null>(null)
  const [loading, setLoading] = useState(false)
  const [testLoading, setTestLoading] = useState(false)
  const [testResult, setTestResult] = useState<string | null>(null)
  const [opened, { open, close }] = useDisclosure(false)
  
  const form = useForm<ApiTestForm>({
    initialValues: {
      endpoint: '/api/v1/messages/send',
      method: 'POST',
      apiKey: '',
      body: JSON.stringify({
        to: '+1234567890',
        message: 'Hello from API test!',
        instance_id: 'your_instance_id'
      }, null, 2)
    }
  })

  const loadSwaggerSpec = async () => {
    try {
      setLoading(true)
      // Try to load from Baileys server
      const response = await fetch('http://localhost:3005/api-docs.json')
      if (response.ok) {
        const spec = await response.json()
        setSwaggerSpec(spec)
        notifications.show({
          title: 'Success',
          message: 'API documentation loaded successfully',
          color: 'green'
        })
      } else {
        // Server responded but with error status - load mock
        console.warn('Server responded with status:', response.status)
        setSwaggerSpec(getMockSwaggerSpec())
        notifications.show({
          title: 'Info',
          message: 'API server unavailable. Loaded mock API documentation.',
          color: 'blue'
        })
      }
    } catch (error) {
      console.error('Failed to load Swagger spec:', error)
      // Network error or server not running - load mock specification
      setSwaggerSpec(getMockSwaggerSpec())
      notifications.show({
        title: 'Info',
        message: 'Loaded mock API documentation. Start the API server for live docs.',
        color: 'blue'
      })
    } finally {
      setLoading(false)
    }
  }

  const testApiEndpoint = async (values: ApiTestForm) => {
    try {
      setTestLoading(true)
      const response = await fetch(`http://localhost:3005${values.endpoint}`, {
        method: values.method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${values.apiKey}`
        },
        body: values.method !== 'GET' ? values.body : undefined
      })
      
      const result = await response.json()
      setTestResult(JSON.stringify({
        status: response.status,
        statusText: response.statusText,
        data: result
      }, null, 2))
      
      notifications.show({
        title: response.ok ? 'Success' : 'Error',
        message: `API test ${response.ok ? 'completed' : 'failed'}: ${response.status}`,
        color: response.ok ? 'green' : 'red'
      })
    } catch (error) {
      setTestResult(JSON.stringify({
        error: 'Failed to connect to API server',
        message: error instanceof Error ? error.message : 'Unknown error'
      }, null, 2))
      notifications.show({
        title: 'Error',
        message: 'Failed to test API endpoint',
        color: 'red'
      })
    } finally {
      setTestLoading(false)
    }
  }

  const getMockSwaggerSpec = (): SwaggerSpec => ({
    openapi: '3.0.0',
    info: {
      title: 'WhatsApp Business API',
      version: '1.0.0',
      description: 'RESTful API for WhatsApp Business messaging and management'
    },
    servers: [
      {
        url: 'http://localhost:3005/api/v1',
        description: 'Local development server'
      },
      {
        url: 'https://api.yourdomain.com/v1',
        description: 'Production server'
      }
    ],
    paths: {
      '/messages/send': {
        post: {
          summary: 'Send WhatsApp message',
          description: 'Send a text message to a WhatsApp contact',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    to: { type: 'string', description: 'Recipient phone number' },
                    message: { type: 'string', description: 'Message content' },
                    instance_id: { type: 'string', description: 'WhatsApp instance ID' }
                  }
                }
              }
            }
          },
          responses: {
            '200': { description: 'Message sent successfully' },
            '400': { description: 'Invalid request' },
            '401': { description: 'Unauthorized' }
          }
        }
      },
      '/instances': {
        get: {
          summary: 'List WhatsApp instances',
          description: 'Get all WhatsApp instances for the authenticated user',
          responses: {
            '200': { description: 'List of instances' },
            '401': { description: 'Unauthorized' }
          }
        }
      },
      '/contacts': {
        get: {
          summary: 'List contacts',
          description: 'Get contacts from WhatsApp instance',
          parameters: [
            {
              name: 'instance_id',
              in: 'query',
              required: true,
              schema: { type: 'string' }
            }
          ],
          responses: {
            '200': { description: 'List of contacts' },
            '401': { description: 'Unauthorized' }
          }
        }
      }
    }
  })

  return (
    <Container size="xl" py="md">
      <CustomerHeader
        title="API Documentation"
        subtitle="Interactive API documentation and testing tools"
        badge={{ label: 'Swagger/OpenAPI', color: 'green' }}
      />

      <Stack gap="lg">
        {/* Quick Actions */}
        <Card withBorder padding="lg">
          <Group justify="space-between" mb="md">
            <Group gap="sm">
              <IconApi size={24} color="#85EA2D" />
              <div>
                <Text size="lg" fw={600}>Interactive API Documentation</Text>
                <Text size="sm" c="dimmed">Explore and test API endpoints with live examples</Text>
              </div>
            </Group>
            <Group gap="sm">
              <Button
                variant="light"
                leftSection={<IconRefresh size="1rem" />}
                onClick={loadSwaggerSpec}
                loading={loading}
              >
                Load API Docs
              </Button>
              <Button
                leftSection={<IconPlaylistAdd size="1rem" />}
                onClick={open}
              >
                Test API
              </Button>
              <Button
                variant="outline"
                leftSection={<IconExternalLink size="1rem" />}
                onClick={() => window.open('http://localhost:3005', '_blank')}
              >
                Open Swagger UI
              </Button>
            </Group>
          </Group>

          <Alert icon={<IconInfoCircle size="1rem" />} color="blue" variant="light">
            <Text size="sm" mb="xs" fw={500}>API Documentation Access:</Text>
            <Text size="sm">
              • <strong>Swagger UI:</strong> Full interactive documentation at http://localhost:3005<br/>
              • <strong>OpenAPI Spec:</strong> JSON specification at http://localhost:3005/api-docs.json<br/>
              • <strong>Live Testing:</strong> Test endpoints directly from this interface
            </Text>
          </Alert>
        </Card>

        {/* API Specification Display */}
        {swaggerSpec && (
          <Card withBorder padding="lg">
            <div style={{ position: 'relative' }}>
              <LoadingOverlay visible={loading} />
              
              <Tabs defaultValue="overview">
                <Tabs.List>
                  <Tabs.Tab value="overview" leftSection={<IconBook size="1rem" />}>
                    Overview
                  </Tabs.Tab>
                  <Tabs.Tab value="endpoints" leftSection={<IconCode size="1rem" />}>
                    Endpoints
                  </Tabs.Tab>
                  <Tabs.Tab value="servers" leftSection={<IconServer size="1rem" />}>
                    Servers
                  </Tabs.Tab>
                </Tabs.List>

                <Tabs.Panel value="overview" pt="md">
                  <Stack gap="md">
                    <Group gap="md">
                      <Badge color="green" size="lg">{swaggerSpec.openapi}</Badge>
                      <Badge variant="light" size="lg">v{swaggerSpec.info.version}</Badge>
                    </Group>
                    
                    <div>
                      <Text size="xl" fw={700} mb="sm">{swaggerSpec.info.title}</Text>
                      <Text size="sm" c="dimmed">{swaggerSpec.info.description}</Text>
                    </div>

                    <Divider />

                    <div>
                      <Text size="lg" fw={600} mb="sm">Authentication</Text>
                      <Text size="sm" mb="xs">Bearer Token authentication required for all endpoints:</Text>
                      <Code block>Authorization: Bearer YOUR_API_KEY</Code>
                    </div>

                    <div>
                      <Text size="lg" fw={600} mb="sm">Rate Limits</Text>
                      <Text size="sm">
                        • 100 requests per minute per API key<br/>
                        • 10,000 messages per day<br/>
                        • Burst limit: 10 requests per second
                      </Text>
                    </div>

                    <Alert color="yellow" title="Getting Started">
                      <Text size="sm">
                        1. Generate an API key from the "Manage API Keys" section<br/>
                        2. Include the key in the Authorization header<br/>
                        3. Start with the /instances endpoint to get your WhatsApp instances<br/>
                        4. Use /messages/send to send your first message
                      </Text>
                    </Alert>
                  </Stack>
                </Tabs.Panel>

                <Tabs.Panel value="endpoints" pt="md">
                  <Stack gap="md">
                    <Text size="lg" fw={600}>Available Endpoints</Text>
                    
                    <Accordion>
                      {Object.entries(swaggerSpec.paths).map(([path, methods]: [string, any]) => (
                        <Accordion.Item key={path} value={path}>
                          <Accordion.Control>
                            <Group>
                              <Code>{path}</Code>
                              <Group gap={4}>
                                {Object.keys(methods).map(method => (
                                  <Badge 
                                    key={method}
                                    color={
                                      method === 'get' ? 'blue' :
                                      method === 'post' ? 'green' :
                                      method === 'put' ? 'orange' :
                                      method === 'delete' ? 'red' : 'gray'
                                    }
                                    size="sm"
                                  >
                                    {method.toUpperCase()}
                                  </Badge>
                                ))}
                              </Group>
                            </Group>
                          </Accordion.Control>
                          <Accordion.Panel>
                            <Stack gap="sm">
                              {Object.entries(methods).map(([method, details]: [string, any]) => (
                                <div key={method}>
                                  <Group gap="sm" mb="xs">
                                    <Badge color="blue" size="sm">{method.toUpperCase()}</Badge>
                                    <Text fw={500}>{details.summary}</Text>
                                  </Group>
                                  <Text size="sm" c="dimmed" mb="sm">{details.description}</Text>
                                  
                                  {details.requestBody && (
                                    <div>
                                      <Text size="sm" fw={500} mb="xs">Request Body:</Text>
                                      <Code block size="sm">
                                        {JSON.stringify(details.requestBody.content?.['application/json']?.schema, null, 2)}
                                      </Code>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </Stack>
                          </Accordion.Panel>
                        </Accordion.Item>
                      ))}
                    </Accordion>
                  </Stack>
                </Tabs.Panel>

                <Tabs.Panel value="servers" pt="md">
                  <Stack gap="md">
                    <Text size="lg" fw={600}>API Servers</Text>
                    
                    <Stack gap="md">
                      {swaggerSpec.servers.map((server, index) => (
                        <Card key={index} withBorder padding="md" bg="gray.0">
                          <Group justify="space-between">
                            <div>
                              <Group gap="sm" mb="xs">
                                <IconWorld size="1rem" />
                                <Text fw={500}>{server.description}</Text>
                              </Group>
                              <Code>{server.url}</Code>
                            </div>
                            <Group gap="xs">
                              <ActionIcon
                                variant="light"
                                onClick={() => navigator.clipboard.writeText(server.url)}
                              >
                                <IconCopy size="1rem" />
                              </ActionIcon>
                              <ActionIcon
                                variant="light"
                                onClick={() => window.open(server.url, '_blank')}
                              >
                                <IconExternalLink size="1rem" />
                              </ActionIcon>
                            </Group>
                          </Group>
                        </Card>
                      ))}
                    </Stack>
                  </Stack>
                </Tabs.Panel>
              </Tabs>
            </div>
          </Card>
        )}

        {/* Load Prompt */}
        {!swaggerSpec && (
          <Card withBorder padding="lg">
            <Center>
              <Stack align="center" gap="md">
                <IconApi size={48} color="#85EA2D" />
                <Text size="lg" fw={600}>Load API Documentation</Text>
                <Text size="sm" c="dimmed" ta="center">
                  Click "Load API Docs" to fetch the latest API specification from the server
                </Text>
                <Button
                  leftSection={<IconApi size="1rem" />}
                  onClick={loadSwaggerSpec}
                  loading={loading}
                >
                  Load API Documentation
                </Button>
              </Stack>
            </Center>
          </Card>
        )}
      </Stack>

      {/* API Test Modal */}
      <Modal opened={opened} onClose={close} title="Test API Endpoint" size="lg">
        <form onSubmit={form.onSubmit(testApiEndpoint)}>
          <Stack gap="md">
            <Alert icon={<IconInfoCircle size="1rem" />} color="blue">
              Test API endpoints directly from here. Make sure you have a valid API key.
            </Alert>

            <Group grow>
              <Select
                label="HTTP Method"
                data={[
                  { value: 'GET', label: 'GET' },
                  { value: 'POST', label: 'POST' },
                  { value: 'PUT', label: 'PUT' },
                  { value: 'DELETE', label: 'DELETE' }
                ]}
                {...form.getInputProps('method')}
                required
              />
              <TextInput
                label="Endpoint"
                placeholder="/api/v1/messages/send"
                {...form.getInputProps('endpoint')}
                required
              />
            </Group>

            <TextInput
              label="API Key"
              placeholder="sk_live_your_api_key_here"
              leftSection={<IconKey size="1rem" />}
              {...form.getInputProps('apiKey')}
              required
            />

            <div>
              <Text size="sm" fw={500} mb="xs">Request Body (JSON)</Text>
              <textarea
                style={{
                  width: '100%',
                  minHeight: '120px',
                  fontFamily: 'monospace',
                  fontSize: '12px',
                  padding: '8px',
                  border: '1px solid #ced4da',
                  borderRadius: '4px'
                }}
                {...form.getInputProps('body')}
              />
            </div>

            {testResult && (
              <div>
                <Text size="sm" fw={500} mb="xs">Response:</Text>
                <Code block style={{ maxHeight: '200px', overflow: 'auto' }}>
                  {testResult}
                </Code>
              </div>
            )}

            <Group justify="flex-end">
              <Button variant="subtle" onClick={close}>
                Close
              </Button>
              <Button
                type="submit"
                leftSection={<IconCode size="1rem" />}
                loading={testLoading}
              >
                Send Request
              </Button>
            </Group>
          </Stack>
        </form>
      </Modal>
    </Container>
  )
}