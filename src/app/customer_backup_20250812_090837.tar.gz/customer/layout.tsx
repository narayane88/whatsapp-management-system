import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import CustomerLayout from '@/components/customer/CustomerLayout'

export default async function CustomerLayoutWrapper({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getServerSession(authOptions)
  
  if (!session?.user) {
    redirect('/auth/signin?callbackUrl=/customer')
  }

  if (session.user.role !== 'CUSTOMER') {
    redirect('/dashboard')
  }

  return (
    <CustomerLayout user={session.user}>
      {children}
    </CustomerLayout>
  )
}