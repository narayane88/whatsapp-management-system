'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  TextInput,
  Select,
  Text,
  Title,
  Badge,
  Table,
  Pagination,
  ActionIcon,
  Modal,
  Alert,
  LoadingOverlay,
  Grid,
  Tabs
} from '@mantine/core'
import {
  IconBrandWhatsapp,
  IconSend,
  IconSearch,
  IconEye,
  IconRefresh,
  IconCalendar,
  IconPhone,
  IconMessage,
  IconCheck,
  IconX,
  IconClock,
  IconPhoto,
  IconFile,
  IconVideo,
  IconMusic,
  IconMapPin
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import { useDisclosure } from '@mantine/hooks'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface SentMessage {
  id: string
  deviceId: string
  deviceName: string
  recipient: string
  recipientName?: string
  message: string
  messageType: 'text' | 'image' | 'document' | 'video' | 'audio' | 'location'
  attachmentUrl?: string
  status: 'SENT' | 'DELIVERED' | 'READ' | 'FAILED'
  sentAt: string
  deliveredAt?: string
  readAt?: string
  error?: string
  messageId?: string
  priority: 'NORMAL' | 'HIGH' | 'URGENT'
}

interface ConnectedDevice {
  id: string
  accountName: string
  phoneNumber?: string
  status: string
  serverName: string
}

export default function SentMessagesPage() {
  const [messages, setMessages] = useState<SentMessage[]>([])
  const [devices, setDevices] = useState<ConnectedDevice[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDevice, setFilterDevice] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [filterType, setFilterType] = useState('')
  const [dateRange, setDateRange] = useState('today')
  const [selectedMessage, setSelectedMessage] = useState<SentMessage | null>(null)
  const [detailsOpened, { open: openDetails, close: closeDetails }] = useDisclosure(false)

  useEffect(() => {
    fetchDevices()
    fetchSentMessages()
  }, [currentPage, filterDevice, filterStatus, filterType, dateRange, searchTerm])

  const fetchDevices = async () => {
    try {
      const response = await fetch('/api/customer/host/connections')
      if (response.ok) {
        const allDevices = await response.json()
        setDevices(allDevices)
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    }
  }

  const fetchSentMessages = async () => {
    try {
      setLoading(true)
      
      const params = new URLSearchParams({
        userId: '1', // TODO: Get from auth context
        page: currentPage.toString(),
        limit: '20'
      })

      if (filterDevice) params.append('deviceId', filterDevice)
      if (filterStatus) params.append('status', filterStatus)
      if (filterType) params.append('messageType', filterType)
      if (searchTerm) params.append('search', searchTerm)
      if (dateRange !== 'all') params.append('dateRange', dateRange)

      const response = await fetch(`/api/customer/whatsapp/sent?${params.toString()}`)
      const result = await response.json()

      if (response.ok) {
        // Map API response to component interface
        const mappedMessages: SentMessage[] = (result.messages || []).map((msg: any) => ({
          id: msg.id.toString(),
          deviceId: msg.instance_id,
          deviceName: msg.instance_name || 'Unknown Device',
          recipient: msg.to_number,
          recipientName: msg.recipient_name,
          message: msg.message_content,
          messageType: msg.message_type as any,
          attachmentUrl: msg.attachment_url,
          status: msg.delivery_status?.toUpperCase() || 'SENT',
          sentAt: msg.sent_at,
          deliveredAt: msg.delivered_at,
          readAt: msg.read_at,
          error: msg.error_message,
          messageId: msg.whatsapp_message_id,
          priority: msg.priority?.toUpperCase() || 'NORMAL'
        }))

        setMessages(mappedMessages)
        setTotalPages(result.pagination?.totalPages || 1)
      } else {
        throw new Error(result.error || 'Failed to fetch sent messages')
      }
    } catch (error) {
      console.error('Error fetching sent messages:', error)
      notifications.show({
        title: 'Error',
        message: 'Failed to load sent messages',
        color: 'red'
      })
      // Fallback to empty array on error
      setMessages([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'READ': return 'green'
      case 'delivered': return 'blue'
      case 'sent': return 'yellow'
      case 'failed': return 'red'
      default: return 'gray'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'read': return <IconCheck size="1rem" style={{ color: 'green' }} />
      case 'delivered': return <IconCheck size="1rem" style={{ color: 'blue' }} />
      case 'sent': return <IconClock size="1rem" style={{ color: 'orange' }} />
      case 'failed': return <IconX size="1rem" style={{ color: 'red' }} />
      default: return <IconClock size="1rem" />
    }
  }

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case 'image': return <IconPhoto size="1rem" color="#9c27b0" />
      case 'document': return <IconFile size="1rem" color="#2196f3" />
      case 'video': return <IconVideo size="1rem" color="#f44336" />
      case 'audio': return <IconMusic size="1rem" color="#ff9800" />
      case 'location': return <IconMapPin size="1rem" color="#4caf50" />
      default: return <IconMessage size="1rem" color="#607d8b" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'URGENT': return 'red'
      case 'HIGH': return 'orange'
      case 'NORMAL': return 'blue'
      default: return 'gray'
    }
  }

  const viewMessageDetails = (message: SentMessage) => {
    setSelectedMessage(message)
    openDetails()
  }

  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.recipient.includes(searchTerm) ||
                         (message.recipientName?.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesDevice = !filterDevice || message.deviceId === filterDevice
    const matchesStatus = !filterStatus || message.status.toLowerCase() === filterStatus.toLowerCase()
    const matchesType = !filterType || message.messageType === filterType

    return matchesSearch && matchesDevice && matchesStatus && matchesType
  })

  const getMessageStats = () => {
    const total = messages.length
    const sent = messages.filter(m => m.status === 'SENT').length
    const delivered = messages.filter(m => m.status === 'DELIVERED').length
    const read = messages.filter(m => m.status === 'READ').length
    const failed = messages.filter(m => m.status === 'FAILED').length

    return { total, sent, delivered, read, failed }
  }

  const stats = getMessageStats()

  if (loading) {
    return <LoadingOverlay visible />
  }

  return (
    <div>
      <CustomerHeader 
        title="Sent Messages"
        subtitle="View and track your sent WhatsApp message history and delivery status"
        badge={{ label: 'Message History', color: 'green' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Stats Cards */}
          <Grid>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#f8f9fa' }}>
                <Group gap="sm">
                  <IconSend size={20} color="#2196f3" />
                  <div>
                    <Text size="xs" c="dimmed">Total Sent</Text>
                    <Text size="lg" fw={600}>{stats.total}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e8f5e8' }}>
                <Group gap="sm">
                  <IconCheck size={20} color="#4caf50" />
                  <div>
                    <Text size="xs" c="dimmed">Read</Text>
                    <Text size="lg" fw={600}>{stats.read}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e3f2fd' }}>
                <Group gap="sm">
                  <IconCheck size={20} color="#2196f3" />
                  <div>
                    <Text size="xs" c="dimmed">Delivered</Text>
                    <Text size="lg" fw={600}>{stats.delivered}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#fff3e0' }}>
                <Group gap="sm">
                  <IconClock size={20} color="#ff9800" />
                  <div>
                    <Text size="xs" c="dimmed">Sent</Text>
                    <Text size="lg" fw={600}>{stats.sent}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#ffebee' }}>
                <Group gap="sm">
                  <IconX size={20} color="#f44336" />
                  <div>
                    <Text size="xs" c="dimmed">Failed</Text>
                    <Text size="lg" fw={600}>{stats.failed}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
          </Grid>

          {/* Filters */}
          <Card withBorder padding="lg">
            <Title order={4} mb="md">Filter Messages</Title>
            <Grid>
              <Grid.Col span={{ base: 12, md: 3 }}>
                <TextInput
                  placeholder="Search messages, recipients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  leftSection={<IconSearch size="1rem" />}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Filter by device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'}`
                  }))}
                  value={filterDevice}
                  onChange={(value) => setFilterDevice(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Filter by status"
                  data={[
                    { value: 'sent', label: 'Sent' },
                    { value: 'delivered', label: 'Delivered' },
                    { value: 'read', label: 'Read' },
                    { value: 'failed', label: 'Failed' }
                  ]}
                  value={filterStatus}
                  onChange={(value) => setFilterStatus(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Message type"
                  data={[
                    { value: 'text', label: 'Text' },
                    { value: 'image', label: 'Image' },
                    { value: 'document', label: 'Document' },
                    { value: 'video', label: 'Video' },
                    { value: 'audio', label: 'Audio' },
                    { value: 'location', label: 'Location' }
                  ]}
                  value={filterType}
                  onChange={(value) => setFilterType(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Date range"
                  data={[
                    { value: 'today', label: 'Today' },
                    { value: 'week', label: 'This Week' },
                    { value: 'month', label: 'This Month' },
                    { value: 'all', label: 'All Time' }
                  ]}
                  value={dateRange}
                  onChange={(value) => setDateRange(value || 'today')}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 1 }}>
                <Button
                  variant="light"
                  onClick={fetchSentMessages}
                  fullWidth
                >
                  <IconRefresh size="1rem" />
                </Button>
              </Grid.Col>
            </Grid>
          </Card>

          {/* Messages Table */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>Message History ({filteredMessages.length})</Title>
            </Group>

            {filteredMessages.length > 0 ? (
              <>
                <Table striped highlightOnHover>
                  <Table.Thead>
                    <Table.Tr>
                      <Table.Th>Type</Table.Th>
                      <Table.Th>Recipient</Table.Th>
                      <Table.Th>Message</Table.Th>
                      <Table.Th>Device</Table.Th>
                      <Table.Th>Status</Table.Th>
                      <Table.Th>Priority</Table.Th>
                      <Table.Th>Sent At</Table.Th>
                      <Table.Th>Actions</Table.Th>
                    </Table.Tr>
                  </Table.Thead>
                  <Table.Tbody>
                    {filteredMessages.map((message) => (
                      <Table.Tr key={message.id}>
                        <Table.Td>
                          <Group gap="xs">
                            {getMessageTypeIcon(message.messageType)}
                            <Text size="xs" tt="capitalize">{message.messageType}</Text>
                          </Group>
                        </Table.Td>
                        <Table.Td>
                          <div>
                            <Text size="sm" fw={500}>
                              {message.recipientName || message.recipient}
                            </Text>
                            {message.recipientName && (
                              <Text size="xs" c="dimmed">{message.recipient}</Text>
                            )}
                          </div>
                        </Table.Td>
                        <Table.Td>
                          <Text size="sm" lineClamp={2} style={{ maxWidth: 200 }}>
                            {message.messageType === 'text' ? message.message : 
                             `[${message.messageType.toUpperCase()}] ${message.message}`}
                          </Text>
                        </Table.Td>
                        <Table.Td>
                          <Text size="xs" c="dimmed">{message.deviceName}</Text>
                        </Table.Td>
                        <Table.Td>
                          <Group gap="xs">
                            {getStatusIcon(message.status)}
                            <Badge 
                              color={getStatusColor(message.status)} 
                              size="sm"
                              variant="light"
                            >
                              {message.status}
                            </Badge>
                          </Group>
                        </Table.Td>
                        <Table.Td>
                          <Badge 
                            color={getPriorityColor(message.priority)} 
                            size="xs"
                            variant="light"
                          >
                            {message.priority}
                          </Badge>
                        </Table.Td>
                        <Table.Td>
                          <Text size="xs">
                            {new Date(message.sentAt).toLocaleString()}
                          </Text>
                        </Table.Td>
                        <Table.Td>
                          <ActionIcon
                            variant="subtle"
                            color="blue"
                            onClick={() => viewMessageDetails(message)}
                            title="View Details"
                          >
                            <IconEye size="1rem" />
                          </ActionIcon>
                        </Table.Td>
                      </Table.Tr>
                    ))}
                  </Table.Tbody>
                </Table>

                {totalPages > 1 && (
                  <Group justify="center" mt="md">
                    <Pagination 
                      total={totalPages} 
                      value={currentPage} 
                      onChange={setCurrentPage}
                    />
                  </Group>
                )}
              </>
            ) : (
              <Alert color="blue">
                <Text size="sm" fw={500}>No sent messages found</Text>
                <Text size="xs">
                  {searchTerm || filterDevice || filterStatus || filterType ? 
                    'Try adjusting your filters or search terms.' : 
                    'Start sending messages to see them here.'}
                </Text>
              </Alert>
            )}
          </Card>

          {/* Message Details Modal */}
          <Modal
            opened={detailsOpened}
            onClose={closeDetails}
            title="Message Details"
            size="lg"
          >
            {selectedMessage && (
              <Stack gap="md">
                <Group gap="md">
                  <Badge color={getStatusColor(selectedMessage.status)} size="lg">
                    {selectedMessage.status}
                  </Badge>
                  <Badge color={getPriorityColor(selectedMessage.priority)} size="lg">
                    {selectedMessage.priority}
                  </Badge>
                  <Badge variant="light">
                    {selectedMessage.messageType.toUpperCase()}
                  </Badge>
                </Group>

                <Grid>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Recipient:</Text>
                    <Text size="sm">{selectedMessage.recipientName || selectedMessage.recipient}</Text>
                    {selectedMessage.recipientName && (
                      <Text size="xs" c="dimmed">{selectedMessage.recipient}</Text>
                    )}
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Device:</Text>
                    <Text size="sm">{selectedMessage.deviceName}</Text>
                  </Grid.Col>
                </Grid>

                <div>
                  <Text size="sm" fw={500} mb="xs">Message:</Text>
                  <Text 
                    size="sm" 
                    style={{ 
                      backgroundColor: '#f8f9fa', 
                      padding: '12px', 
                      borderRadius: '8px',
                      border: '1px solid #e9ecef'
                    }}
                  >
                    {selectedMessage.message}
                  </Text>
                </div>

                {selectedMessage.attachmentUrl && (
                  <div>
                    <Text size="sm" fw={500} mb="xs">Attachment:</Text>
                    <Text size="sm" c="blue" style={{ wordBreak: 'break-all' }}>
                      {selectedMessage.attachmentUrl}
                    </Text>
                  </div>
                )}

                <Grid>
                  <Grid.Col span={4}>
                    <Text size="sm" fw={500}>Sent:</Text>
                    <Text size="sm">{new Date(selectedMessage.sentAt).toLocaleString()}</Text>
                  </Grid.Col>
                  {selectedMessage.deliveredAt && (
                    <Grid.Col span={4}>
                      <Text size="sm" fw={500}>Delivered:</Text>
                      <Text size="sm">{new Date(selectedMessage.deliveredAt).toLocaleString()}</Text>
                    </Grid.Col>
                  )}
                  {selectedMessage.readAt && (
                    <Grid.Col span={4}>
                      <Text size="sm" fw={500}>Read:</Text>
                      <Text size="sm">{new Date(selectedMessage.readAt).toLocaleString()}</Text>
                    </Grid.Col>
                  )}
                </Grid>

                {selectedMessage.messageId && (
                  <div>
                    <Text size="sm" fw={500}>Message ID:</Text>
                    <Text size="xs" family="monospace" c="dimmed">{selectedMessage.messageId}</Text>
                  </div>
                )}

                {selectedMessage.error && (
                  <Alert color="red">
                    <Text size="sm" fw={500}>Error:</Text>
                    <Text size="sm">{selectedMessage.error}</Text>
                  </Alert>
                )}
              </Stack>
            )}
          </Modal>
        </Stack>
      </Container>
    </div>
  )
}