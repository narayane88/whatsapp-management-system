'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  TextInput,
  Select,
  Text,
  Title,
  Badge,
  Table,
  ActionIcon,
  Modal,
  Alert,
  LoadingOverlay,
  Grid,
  Textarea
} from '@mantine/core'
import {
  IconBrandWhatsapp,
  IconClock,
  IconSearch,
  IconEye,
  IconRefresh,
  IconEdit,
  IconTrash,
  IconPlayerPlay,
  IconPlayerPause,
  IconPlus,
  IconCalendar,
  IconMessage,
  IconPhoto,
  IconFile,
  IconVideo,
  IconMusic,
  IconMapPin
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import { useDisclosure } from '@mantine/hooks'
import { useForm } from '@mantine/form'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface ScheduledMessage {
  id: string
  deviceId: string
  deviceName: string
  recipient: string
  recipientName?: string
  message: string
  messageType: 'text' | 'image' | 'document' | 'video' | 'audio' | 'location'
  attachmentUrl?: string
  scheduledAt: string
  status: 'PENDING' | 'PAUSED' | 'SENT' | 'FAILED' | 'CANCELLED'
  createdAt: string
  priority: 'NORMAL' | 'HIGH' | 'URGENT'
  attempts: number
  error?: string
  isRecurring?: boolean
  recurringPattern?: 'daily' | 'weekly' | 'monthly'
}

interface ConnectedDevice {
  id: string
  accountName: string
  phoneNumber?: string
  status: string
  serverName: string
}

interface NewScheduledMessageForm {
  deviceId: string
  recipient: string
  message: string
  messageType: 'text' | 'image' | 'document' | 'video' | 'audio' | 'location'
  attachmentUrl?: string
  scheduledAt: string
  priority: 'NORMAL' | 'HIGH' | 'URGENT'
  isRecurring: boolean
  recurringPattern?: 'daily' | 'weekly' | 'monthly'
}

export default function ScheduledMessagesPage() {
  const [messages, setMessages] = useState<ScheduledMessage[]>([])
  const [devices, setDevices] = useState<ConnectedDevice[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDevice, setFilterDevice] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [selectedMessage, setSelectedMessage] = useState<ScheduledMessage | null>(null)
  const [detailsOpened, { open: openDetails, close: closeDetails }] = useDisclosure(false)
  const [createOpened, { open: openCreate, close: closeCreate }] = useDisclosure(false)
  const [editOpened, { open: openEdit, close: closeEdit }] = useDisclosure(false)

  const form = useForm<NewScheduledMessageForm>({
    initialValues: {
      deviceId: '',
      recipient: '',
      message: '',
      messageType: 'text',
      attachmentUrl: '',
      scheduledAt: '',
      priority: 'NORMAL',
      isRecurring: false,
      recurringPattern: undefined
    },
    validate: {
      deviceId: (value) => (!value ? 'Device is required' : null),
      recipient: (value) => (!value ? 'Recipient is required' : null),
      message: (value) => (!value ? 'Message is required' : null),
      scheduledAt: (value) => (!value ? 'Schedule time is required' : null)
    }
  })

  useEffect(() => {
    fetchDevices()
    fetchScheduledMessages()
  }, [filterDevice, filterStatus, searchTerm])

  const fetchDevices = async () => {
    try {
      const response = await fetch('/api/customer/host/connections')
      if (response.ok) {
        const allDevices = await response.json()
        const connectedDevices = allDevices.filter((device: any) => device.status === 'CONNECTED')
        setDevices(connectedDevices)
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    }
  }

  const fetchScheduledMessages = async () => {
    try {
      setLoading(true)
      // Mock data - replace with actual API call
      const mockMessages: ScheduledMessage[] = [
        {
          id: '1',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          recipient: '+919876543210',
          recipientName: 'John Customer',
          message: 'Reminder: Your appointment is scheduled for tomorrow at 2 PM.',
          messageType: 'text',
          scheduledAt: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
          status: 'PENDING',
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          priority: 'HIGH',
          attempts: 0,
          isRecurring: false
        },
        {
          id: '2',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          recipient: '+919876543211',
          message: 'Good morning! Your daily report is ready.',
          messageType: 'text',
          scheduledAt: new Date().toISOString().split('T')[0] + 'T09:00:00', // Daily at 9 AM
          status: 'PENDING',
          createdAt: new Date(Date.now() - 7200000).toISOString(),
          priority: 'NORMAL',
          attempts: 0,
          isRecurring: true,
          recurringPattern: 'daily'
        },
        {
          id: '3',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          recipient: '+919876543212',
          recipientName: 'Jane Smith',
          message: 'Weekly newsletter with latest updates',
          messageType: 'text',
          scheduledAt: new Date(Date.now() + 604800000).toISOString(), // Next week
          status: 'PAUSED',
          createdAt: new Date(Date.now() - 10800000).toISOString(),
          priority: 'NORMAL',
          attempts: 0,
          isRecurring: true,
          recurringPattern: 'weekly'
        },
        {
          id: '4',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          recipient: '+919876543213',
          message: 'Payment reminder: Your invoice is due in 3 days.',
          messageType: 'text',
          scheduledAt: new Date(Date.now() - 3600000).toISOString(), // Past due
          status: 'FAILED',
          createdAt: new Date(Date.now() - 14400000).toISOString(),
          priority: 'URGENT',
          attempts: 3,
          error: 'Recipient phone number not found'
        }
      ]
      
      setMessages(mockMessages)
    } catch (error) {
      console.error('Error fetching scheduled messages:', error)
      notifications.show({
        title: 'Error',
        message: 'Failed to load scheduled messages',
        color: 'red'
      })
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'blue'
      case 'PAUSED': return 'yellow'
      case 'SENT': return 'green'
      case 'FAILED': return 'red'
      case 'CANCELLED': return 'gray'
      default: return 'gray'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'URGENT': return 'red'
      case 'HIGH': return 'orange'
      case 'NORMAL': return 'blue'
      default: return 'gray'
    }
  }

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case 'image': return <IconPhoto size="1rem" color="#9c27b0" />
      case 'document': return <IconFile size="1rem" color="#2196f3" />
      case 'video': return <IconVideo size="1rem" color="#f44336" />
      case 'audio': return <IconMusic size="1rem" color="#ff9800" />
      case 'location': return <IconMapPin size="1rem" color="#4caf50" />
      default: return <IconMessage size="1rem" color="#607d8b" />
    }
  }

  const createScheduledMessage = async (values: NewScheduledMessageForm) => {
    try {
      const device = devices.find(d => d.id === values.deviceId)
      if (!device) {
        notifications.show({
          title: 'Error',
          message: 'Selected device not found',
          color: 'red'
        })
        return
      }

      const newMessage: ScheduledMessage = {
        id: Date.now().toString(),
        deviceId: values.deviceId,
        deviceName: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`,
        recipient: values.recipient,
        message: values.message,
        messageType: values.messageType,
        attachmentUrl: values.attachmentUrl,
        scheduledAt: values.scheduledAt,
        status: 'PENDING',
        createdAt: new Date().toISOString(),
        priority: values.priority,
        attempts: 0,
        isRecurring: values.isRecurring,
        recurringPattern: values.recurringPattern
      }

      setMessages(prev => [newMessage, ...prev])
      
      notifications.show({
        title: 'Scheduled Message Created',
        message: `Message scheduled for ${new Date(values.scheduledAt).toLocaleString()}`,
        color: 'green'
      })

      form.reset()
      closeCreate()
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to schedule message',
        color: 'red'
      })
    }
  }

  const pauseMessage = async (messageId: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, status: 'PAUSED' as const } : msg
    ))
    
    notifications.show({
      title: 'Message Paused',
      message: 'Scheduled message has been paused',
      color: 'yellow'
    })
  }

  const resumeMessage = async (messageId: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, status: 'PENDING' as const } : msg
    ))
    
    notifications.show({
      title: 'Message Resumed',
      message: 'Scheduled message has been resumed',
      color: 'green'
    })
  }

  const cancelMessage = async (messageId: string) => {
    if (!confirm('Are you sure you want to cancel this scheduled message?')) {
      return
    }

    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, status: 'CANCELLED' as const } : msg
    ))
    
    notifications.show({
      title: 'Message Cancelled',
      message: 'Scheduled message has been cancelled',
      color: 'red'
    })
  }

  const sendImmediately = async (messageId: string) => {
    if (!confirm('Send this message immediately?')) {
      return
    }

    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, status: 'SENT' as const } : msg
    ))
    
    notifications.show({
      title: 'Message Sent',
      message: 'Message has been sent immediately',
      color: 'green'
    })
  }

  const deleteMessage = async (messageId: string) => {
    if (!confirm('Are you sure you want to delete this scheduled message?')) {
      return
    }

    setMessages(prev => prev.filter(msg => msg.id !== messageId))
    
    notifications.show({
      title: 'Message Deleted',
      message: 'Scheduled message has been deleted',
      color: 'green'
    })
  }

  const viewMessageDetails = (message: ScheduledMessage) => {
    setSelectedMessage(message)
    openDetails()
  }

  const editMessage = (message: ScheduledMessage) => {
    form.setValues({
      deviceId: message.deviceId,
      recipient: message.recipient,
      message: message.message,
      messageType: message.messageType,
      attachmentUrl: message.attachmentUrl || '',
      scheduledAt: message.scheduledAt,
      priority: message.priority,
      isRecurring: message.isRecurring || false,
      recurringPattern: message.recurringPattern
    })
    setSelectedMessage(message)
    openEdit()
  }

  const updateScheduledMessage = async (values: NewScheduledMessageForm) => {
    if (!selectedMessage) return

    try {
      const device = devices.find(d => d.id === values.deviceId)
      if (!device) {
        notifications.show({
          title: 'Error',
          message: 'Selected device not found',
          color: 'red'
        })
        return
      }

      setMessages(prev => prev.map(msg => 
        msg.id === selectedMessage.id ? {
          ...msg,
          deviceId: values.deviceId,
          deviceName: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`,
          recipient: values.recipient,
          message: values.message,
          messageType: values.messageType,
          attachmentUrl: values.attachmentUrl,
          scheduledAt: values.scheduledAt,
          priority: values.priority,
          isRecurring: values.isRecurring,
          recurringPattern: values.recurringPattern
        } : msg
      ))

      notifications.show({
        title: 'Message Updated',
        message: 'Scheduled message has been updated',
        color: 'green'
      })

      closeEdit()
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to update scheduled message',
        color: 'red'
      })
    }
  }

  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.recipient.includes(searchTerm) ||
                         (message.recipientName?.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesDevice = !filterDevice || message.deviceId === filterDevice
    const matchesStatus = !filterStatus || message.status.toLowerCase() === filterStatus.toLowerCase()

    return matchesSearch && matchesDevice && matchesStatus
  })

  const getMessageStats = () => {
    const total = messages.length
    const pending = messages.filter(m => m.status === 'PENDING').length
    const paused = messages.filter(m => m.status === 'PAUSED').length
    const failed = messages.filter(m => m.status === 'FAILED').length
    const recurring = messages.filter(m => m.isRecurring).length

    return { total, pending, paused, failed, recurring }
  }

  const stats = getMessageStats()

  if (loading) {
    return <LoadingOverlay visible />
  }

  return (
    <div>
      <CustomerHeader 
        title="Scheduled Messages"
        subtitle="Manage and monitor your scheduled WhatsApp messages and recurring campaigns"
        badge={{ label: 'Scheduler', color: 'blue' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Stats Cards */}
          <Grid>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#f8f9fa' }}>
                <Group gap="sm">
                  <IconClock size={20} color="#2196f3" />
                  <div>
                    <Text size="xs" c="dimmed">Total Scheduled</Text>
                    <Text size="lg" fw={600}>{stats.total}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e3f2fd' }}>
                <Group gap="sm">
                  <IconPlayerPlay size={20} color="#1976d2" />
                  <div>
                    <Text size="xs" c="dimmed">Pending</Text>
                    <Text size="lg" fw={600}>{stats.pending}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#fff3e0' }}>
                <Group gap="sm">
                  <IconPlayerPause size={20} color="#f57c00" />
                  <div>
                    <Text size="xs" c="dimmed">Paused</Text>
                    <Text size="lg" fw={600}>{stats.paused}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#ffebee' }}>
                <Group gap="sm">
                  <IconTrash size={20} color="#d32f2f" />
                  <div>
                    <Text size="xs" c="dimmed">Failed</Text>
                    <Text size="lg" fw={600}>{stats.failed}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 2.4 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e8f5e8' }}>
                <Group gap="sm">
                  <IconRefresh size={20} color="#388e3c" />
                  <div>
                    <Text size="xs" c="dimmed">Recurring</Text>
                    <Text size="lg" fw={600}>{stats.recurring}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
          </Grid>

          {/* Controls */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>Manage Scheduled Messages</Title>
              <Button
                leftSection={<IconPlus size="1rem" />}
                onClick={openCreate}
                disabled={devices.length === 0}
              >
                Schedule New Message
              </Button>
            </Group>

            <Grid>
              <Grid.Col span={{ base: 12, md: 4 }}>
                <TextInput
                  placeholder="Search messages, recipients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  leftSection={<IconSearch size="1rem" />}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 3 }}>
                <Select
                  placeholder="Filter by device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'}`
                  }))}
                  value={filterDevice}
                  onChange={(value) => setFilterDevice(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 3 }}>
                <Select
                  placeholder="Filter by status"
                  data={[
                    { value: 'pending', label: 'Pending' },
                    { value: 'paused', label: 'Paused' },
                    { value: 'sent', label: 'Sent' },
                    { value: 'failed', label: 'Failed' },
                    { value: 'cancelled', label: 'Cancelled' }
                  ]}
                  value={filterStatus}
                  onChange={(value) => setFilterStatus(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Button
                  variant="light"
                  onClick={fetchScheduledMessages}
                  fullWidth
                  leftSection={<IconRefresh size="1rem" />}
                >
                  Refresh
                </Button>
              </Grid.Col>
            </Grid>
          </Card>

          {/* Scheduled Messages Table */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>Scheduled Messages ({filteredMessages.length})</Title>
            </Group>

            {filteredMessages.length > 0 ? (
              <Table striped highlightOnHover>
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>Type</Table.Th>
                    <Table.Th>Recipient</Table.Th>
                    <Table.Th>Message</Table.Th>
                    <Table.Th>Scheduled For</Table.Th>
                    <Table.Th>Status</Table.Th>
                    <Table.Th>Priority</Table.Th>
                    <Table.Th>Recurring</Table.Th>
                    <Table.Th>Actions</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>
                  {filteredMessages.map((message) => (
                    <Table.Tr key={message.id}>
                      <Table.Td>
                        <Group gap="xs">
                          {getMessageTypeIcon(message.messageType)}
                          <Text size="xs" tt="capitalize">{message.messageType}</Text>
                        </Group>
                      </Table.Td>
                      <Table.Td>
                        <div>
                          <Text size="sm" fw={500}>
                            {message.recipientName || message.recipient}
                          </Text>
                          {message.recipientName && (
                            <Text size="xs" c="dimmed">{message.recipient}</Text>
                          )}
                        </div>
                      </Table.Td>
                      <Table.Td>
                        <Text size="sm" lineClamp={2} style={{ maxWidth: 200 }}>
                          {message.message}
                        </Text>
                      </Table.Td>
                      <Table.Td>
                        <div>
                          <Text size="sm">
                            {new Date(message.scheduledAt).toLocaleString()}
                          </Text>
                          {new Date(message.scheduledAt) < new Date() && message.status === 'PENDING' && (
                            <Badge size="xs" color="red" variant="light" mt={2}>
                              Overdue
                            </Badge>
                          )}
                        </div>
                      </Table.Td>
                      <Table.Td>
                        <Badge 
                          color={getStatusColor(message.status)} 
                          size="sm"
                          variant={message.status === 'FAILED' ? 'filled' : 'light'}
                        >
                          {message.status}
                        </Badge>
                        {message.attempts > 0 && (
                          <Text size="xs" c="dimmed" mt={2}>
                            Attempts: {message.attempts}
                          </Text>
                        )}
                      </Table.Td>
                      <Table.Td>
                        <Badge 
                          color={getPriorityColor(message.priority)} 
                          size="xs"
                          variant="light"
                        >
                          {message.priority}
                        </Badge>
                      </Table.Td>
                      <Table.Td>
                        {message.isRecurring ? (
                          <Badge color="purple" size="xs" variant="light">
                            {message.recurringPattern?.toUpperCase()}
                          </Badge>
                        ) : (
                          <Text size="xs" c="dimmed">One-time</Text>
                        )}
                      </Table.Td>
                      <Table.Td>
                        <Group gap="xs">
                          <ActionIcon
                            variant="subtle"
                            color="blue"
                            onClick={() => viewMessageDetails(message)}
                            title="View Details"
                          >
                            <IconEye size="1rem" />
                          </ActionIcon>
                          
                          {message.status === 'PENDING' && (
                            <>
                              <ActionIcon
                                variant="subtle"
                                color="yellow"
                                onClick={() => pauseMessage(message.id)}
                                title="Pause"
                              >
                                <IconPlayerPause size="1rem" />
                              </ActionIcon>
                              <ActionIcon
                                variant="subtle"
                                color="green"
                                onClick={() => sendImmediately(message.id)}
                                title="Send Now"
                              >
                                <IconPlayerPlay size="1rem" />
                              </ActionIcon>
                            </>
                          )}
                          
                          {message.status === 'PAUSED' && (
                            <ActionIcon
                              variant="subtle"
                              color="green"
                              onClick={() => resumeMessage(message.id)}
                              title="Resume"
                            >
                              <IconPlayerPlay size="1rem" />
                            </ActionIcon>
                          )}
                          
                          {['PENDING', 'PAUSED'].includes(message.status) && (
                            <>
                              <ActionIcon
                                variant="subtle"
                                color="blue"
                                onClick={() => editMessage(message)}
                                title="Edit"
                              >
                                <IconEdit size="1rem" />
                              </ActionIcon>
                              <ActionIcon
                                variant="subtle"
                                color="red"
                                onClick={() => cancelMessage(message.id)}
                                title="Cancel"
                              >
                                <IconTrash size="1rem" />
                              </ActionIcon>
                            </>
                          )}
                          
                          {['SENT', 'FAILED', 'CANCELLED'].includes(message.status) && (
                            <ActionIcon
                              variant="subtle"
                              color="red"
                              onClick={() => deleteMessage(message.id)}
                              title="Delete"
                            >
                              <IconTrash size="1rem" />
                            </ActionIcon>
                          )}
                        </Group>
                      </Table.Td>
                    </Table.Tr>
                  ))}
                </Table.Tbody>
              </Table>
            ) : (
              <Alert color="blue">
                <Text size="sm" fw={500}>No scheduled messages found</Text>
                <Text size="xs">
                  {devices.length === 0 ? 
                    'Connect a WhatsApp device first to schedule messages.' :
                    searchTerm || filterDevice || filterStatus ? 
                    'Try adjusting your filters or search terms.' : 
                    'Click "Schedule New Message" to create your first scheduled message.'}
                </Text>
              </Alert>
            )}
          </Card>

          {/* Create Message Modal */}
          <Modal
            opened={createOpened}
            onClose={closeCreate}
            title="Schedule New Message"
            size="lg"
          >
            <form onSubmit={form.onSubmit(createScheduledMessage)}>
              <Stack gap="md">
                <Select
                  label="Device"
                  placeholder="Select connected device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`
                  }))}
                  {...form.getInputProps('deviceId')}
                  required
                />

                <TextInput
                  label="Recipient"
                  placeholder="+919876543210"
                  {...form.getInputProps('recipient')}
                  required
                />

                <Select
                  label="Message Type"
                  data={[
                    { value: 'text', label: 'Text Message' },
                    { value: 'image', label: 'Image' },
                    { value: 'document', label: 'Document' },
                    { value: 'video', label: 'Video' },
                    { value: 'audio', label: 'Audio' },
                    { value: 'location', label: 'Location' }
                  ]}
                  {...form.getInputProps('messageType')}
                />

                <Textarea
                  label="Message"
                  placeholder="Enter your message..."
                  rows={4}
                  {...form.getInputProps('message')}
                  required
                />

                {form.values.messageType !== 'text' && (
                  <TextInput
                    label={`${form.values.messageType} URL`}
                    placeholder="Enter URL"
                    {...form.getInputProps('attachmentUrl')}
                  />
                )}

                <TextInput
                  label="Schedule Date & Time"
                  type="datetime-local"
                  {...form.getInputProps('scheduledAt')}
                  min={new Date().toISOString().slice(0, 16)}
                  required
                />

                <Select
                  label="Priority"
                  data={[
                    { value: 'NORMAL', label: 'Normal' },
                    { value: 'HIGH', label: 'High' },
                    { value: 'URGENT', label: 'Urgent' }
                  ]}
                  {...form.getInputProps('priority')}
                />

                <Group justify="flex-end">
                  <Button variant="subtle" onClick={closeCreate}>
                    Cancel
                  </Button>
                  <Button type="submit" leftSection={<IconClock size="1rem" />}>
                    Schedule Message
                  </Button>
                </Group>
              </Stack>
            </form>
          </Modal>

          {/* Edit Message Modal */}
          <Modal
            opened={editOpened}
            onClose={closeEdit}
            title="Edit Scheduled Message"
            size="lg"
          >
            <form onSubmit={form.onSubmit(updateScheduledMessage)}>
              <Stack gap="md">
                <Select
                  label="Device"
                  placeholder="Select connected device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`
                  }))}
                  {...form.getInputProps('deviceId')}
                  required
                />

                <TextInput
                  label="Recipient"
                  placeholder="+919876543210"
                  {...form.getInputProps('recipient')}
                  required
                />

                <Select
                  label="Message Type"
                  data={[
                    { value: 'text', label: 'Text Message' },
                    { value: 'image', label: 'Image' },
                    { value: 'document', label: 'Document' },
                    { value: 'video', label: 'Video' },
                    { value: 'audio', label: 'Audio' },
                    { value: 'location', label: 'Location' }
                  ]}
                  {...form.getInputProps('messageType')}
                />

                <Textarea
                  label="Message"
                  placeholder="Enter your message..."
                  rows={4}
                  {...form.getInputProps('message')}
                  required
                />

                {form.values.messageType !== 'text' && (
                  <TextInput
                    label={`${form.values.messageType} URL`}
                    placeholder="Enter URL"
                    {...form.getInputProps('attachmentUrl')}
                  />
                )}

                <TextInput
                  label="Schedule Date & Time"
                  type="datetime-local"
                  {...form.getInputProps('scheduledAt')}
                  min={new Date().toISOString().slice(0, 16)}
                  required
                />

                <Select
                  label="Priority"
                  data={[
                    { value: 'NORMAL', label: 'Normal' },
                    { value: 'HIGH', label: 'High' },
                    { value: 'URGENT', label: 'Urgent' }
                  ]}
                  {...form.getInputProps('priority')}
                />

                <Group justify="flex-end">
                  <Button variant="subtle" onClick={closeEdit}>
                    Cancel
                  </Button>
                  <Button type="submit" leftSection={<IconEdit size="1rem" />}>
                    Update Message
                  </Button>
                </Group>
              </Stack>
            </form>
          </Modal>

          {/* Message Details Modal */}
          <Modal
            opened={detailsOpened}
            onClose={closeDetails}
            title="Scheduled Message Details"
            size="lg"
          >
            {selectedMessage && (
              <Stack gap="md">
                <Group gap="md">
                  <Badge color={getStatusColor(selectedMessage.status)} size="lg">
                    {selectedMessage.status}
                  </Badge>
                  <Badge color={getPriorityColor(selectedMessage.priority)} size="lg">
                    {selectedMessage.priority}
                  </Badge>
                  <Badge variant="light">
                    {selectedMessage.messageType.toUpperCase()}
                  </Badge>
                  {selectedMessage.isRecurring && (
                    <Badge color="purple" variant="light">
                      RECURRING ({selectedMessage.recurringPattern?.toUpperCase()})
                    </Badge>
                  )}
                </Group>

                <Grid>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Recipient:</Text>
                    <Text size="sm">{selectedMessage.recipientName || selectedMessage.recipient}</Text>
                    {selectedMessage.recipientName && (
                      <Text size="xs" c="dimmed">{selectedMessage.recipient}</Text>
                    )}
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Device:</Text>
                    <Text size="sm">{selectedMessage.deviceName}</Text>
                  </Grid.Col>
                </Grid>

                <div>
                  <Text size="sm" fw={500} mb="xs">Message:</Text>
                  <Text 
                    size="sm" 
                    style={{ 
                      backgroundColor: '#f8f9fa', 
                      padding: '12px', 
                      borderRadius: '8px',
                      border: '1px solid #e9ecef'
                    }}
                  >
                    {selectedMessage.message}
                  </Text>
                </div>

                {selectedMessage.attachmentUrl && (
                  <div>
                    <Text size="sm" fw={500} mb="xs">Attachment:</Text>
                    <Text size="sm" c="blue" style={{ wordBreak: 'break-all' }}>
                      {selectedMessage.attachmentUrl}
                    </Text>
                  </div>
                )}

                <Grid>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Scheduled For:</Text>
                    <Text size="sm">{new Date(selectedMessage.scheduledAt).toLocaleString()}</Text>
                    {new Date(selectedMessage.scheduledAt) < new Date() && selectedMessage.status === 'PENDING' && (
                      <Badge size="xs" color="red" variant="light" mt={4}>
                        Overdue
                      </Badge>
                    )}
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Created:</Text>
                    <Text size="sm">{new Date(selectedMessage.createdAt).toLocaleString()}</Text>
                  </Grid.Col>
                </Grid>

                {selectedMessage.attempts > 0 && (
                  <div>
                    <Text size="sm" fw={500}>Attempts:</Text>
                    <Text size="sm">{selectedMessage.attempts}</Text>
                  </div>
                )}

                {selectedMessage.error && (
                  <Alert color="red">
                    <Text size="sm" fw={500}>Error:</Text>
                    <Text size="sm">{selectedMessage.error}</Text>
                  </Alert>
                )}
              </Stack>
            )}
          </Modal>
        </Stack>
      </Container>
    </div>
  )
}