'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  TextInput,
  Textarea,
  Select,
  Text,
  Title,
  Badge,
  Grid,
  Alert,
  Progress,
  Table,
  ActionIcon,
  Modal,
  FileInput,
  Tabs,
  LoadingOverlay,
  NumberInput,
  Switch
} from '@mantine/core'
import {
  IconBrandWhatsapp,
  IconSend,
  IconUpload,
  IconPlus,
  IconTrash,
  IconEdit,
  IconClock,
  IconUsers,
  IconMessage,
  IconFile,
  IconCheck,
  IconX,
  IconRefresh,
  IconPlayerPlay
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import { useDisclosure } from '@mantine/hooks'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface ConnectedDevice {
  id: string
  accountName: string
  phoneNumber?: string
  status: string
  serverName: string
}

interface BulkMessage {
  id: string
  name: string
  message: string
  recipients: string[]
  deviceId: string
  deviceName: string
  status: 'DRAFT' | 'QUEUED' | 'SENDING' | 'COMPLETED' | 'FAILED'
  totalRecipients: number
  sentCount: number
  failedCount: number
  scheduledAt?: string
  createdAt: string
  messageType: 'text' | 'image' | 'document'
  attachmentUrl?: string
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT'
}

interface Recipient {
  id: string
  phoneNumber: string
  name?: string
  status: 'PENDING' | 'SENT' | 'FAILED'
  sentAt?: string
  error?: string
}

export default function BulkMessagingPage() {
  // State management
  const [devices, setDevices] = useState<ConnectedDevice[]>([])
  const [bulkMessages, setBulkMessages] = useState<BulkMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [sendingProgress, setSendingProgress] = useState(0)
  const [activeTab, setActiveTab] = useState('create')
  
  // Modal states
  const [createModalOpened, { open: openCreateModal, close: closeCreateModal }] = useDisclosure(false)
  const [detailsModalOpened, { open: openDetailsModal, close: closeDetailsModal }] = useDisclosure(false)
  const [selectedMessage, setSelectedMessage] = useState<BulkMessage | null>(null)
  
  // Form state
  const [messageName, setMessageName] = useState('')
  const [messageText, setMessageText] = useState('')
  const [messageType, setMessageType] = useState<'text' | 'image' | 'document'>('text')
  const [attachmentUrl, setAttachmentUrl] = useState('')
  const [selectedDevice, setSelectedDevice] = useState('')
  const [priority, setPriority] = useState<'LOW' | 'NORMAL' | 'HIGH' | 'URGENT'>('NORMAL')
  const [scheduleEnabled, setScheduleEnabled] = useState(false)
  const [scheduledDateTime, setScheduledDateTime] = useState('')
  const [minDelay, setMinDelay] = useState(2)
  const [maxDelay, setMaxDelay] = useState(5)
  
  // Recipients management
  const [recipients, setRecipients] = useState<Recipient[]>([])
  const [newRecipient, setNewRecipient] = useState('')
  const [newRecipientName, setNewRecipientName] = useState('')
  const [csvFile, setCsvFile] = useState<File | null>(null)

  useEffect(() => {
    fetchDevices()
    fetchBulkMessages()
  }, [])

  const fetchDevices = async () => {
    try {
      const response = await fetch('/api/customer/host/connections')
      if (response.ok) {
        const allDevices = await response.json()
        const connectedDevices = allDevices.filter((device: any) => device.status === 'CONNECTED')
        setDevices(connectedDevices)
        
        if (connectedDevices.length > 0 && !selectedDevice) {
          setSelectedDevice(connectedDevices[0].id)
        }
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchBulkMessages = async () => {
    try {
      // Mock data for now - replace with actual API call
      const mockMessages: BulkMessage[] = [
        {
          id: '1',
          name: 'Welcome Campaign',
          message: 'Welcome to our service! Thank you for joining us.',
          recipients: ['+919876543210', '+919876543211', '+919876543212'],
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          status: 'COMPLETED',
          totalRecipients: 3,
          sentCount: 3,
          failedCount: 0,
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          messageType: 'text',
          priority: 'NORMAL'
        },
        {
          id: '2',
          name: 'Product Launch',
          message: 'Check out our new product! Limited time offer available.',
          recipients: ['+919876543213', '+919876543214'],
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          status: 'SENDING',
          totalRecipients: 2,
          sentCount: 1,
          failedCount: 0,
          scheduledAt: new Date().toISOString(),
          createdAt: new Date(Date.now() - 1800000).toISOString(),
          messageType: 'text',
          priority: 'HIGH'
        }
      ]
      setBulkMessages(mockMessages)
    } catch (error) {
      console.error('Error fetching bulk messages:', error)
    }
  }

  const addRecipient = () => {
    if (!newRecipient.trim()) return

    // Format phone number
    let formattedNumber = newRecipient.replace(/\D/g, '')
    if (formattedNumber.length === 10 && formattedNumber.match(/^[6-9]/)) {
      formattedNumber = '91' + formattedNumber
    }
    const finalNumber = '+' + formattedNumber

    // Check if already exists
    if (recipients.some(r => r.phoneNumber === finalNumber)) {
      notifications.show({
        title: 'Duplicate Number',
        message: 'This phone number is already in the recipient list',
        color: 'yellow'
      })
      return
    }

    const newRec: Recipient = {
      id: Date.now().toString(),
      phoneNumber: finalNumber,
      name: newRecipientName.trim() || undefined,
      status: 'PENDING'
    }

    setRecipients([...recipients, newRec])
    setNewRecipient('')
    setNewRecipientName('')
  }

  const removeRecipient = (id: string) => {
    setRecipients(recipients.filter(r => r.id !== id))
  }

  const handleCsvUpload = (file: File | null) => {
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      const csv = e.target?.result as string
      const lines = csv.split('\n').filter(line => line.trim())
      const newRecipients: Recipient[] = []

      lines.forEach((line, index) => {
        if (index === 0) return // Skip header if exists
        
        const [phone, name] = line.split(',').map(s => s.trim().replace(/"/g, ''))
        if (phone) {
          let formattedNumber = phone.replace(/\D/g, '')
          if (formattedNumber.length === 10 && formattedNumber.match(/^[6-9]/)) {
            formattedNumber = '91' + formattedNumber
          }
          const finalNumber = '+' + formattedNumber

          if (!recipients.some(r => r.phoneNumber === finalNumber) && 
              !newRecipients.some(r => r.phoneNumber === finalNumber)) {
            newRecipients.push({
              id: `csv_${index}_${Date.now()}`,
              phoneNumber: finalNumber,
              name: name || undefined,
              status: 'PENDING'
            })
          }
        }
      })

      setRecipients([...recipients, ...newRecipients])
      notifications.show({
        title: 'CSV Imported',
        message: `${newRecipients.length} recipients added from CSV`,
        color: 'green'
      })
    }
    reader.readAsText(file)
    setCsvFile(null)
  }

  const createBulkMessage = async () => {
    if (!messageName.trim() || !messageText.trim() || recipients.length === 0 || !selectedDevice) {
      notifications.show({
        title: 'Missing Information',
        message: 'Please fill in all required fields and add at least one recipient',
        color: 'red'
      })
      return
    }

    const device = devices.find(d => d.id === selectedDevice)
    if (!device) {
      notifications.show({
        title: 'Device Not Found',
        message: 'Selected device not found',
        color: 'red'
      })
      return
    }

    try {
      const newBulkMessage: BulkMessage = {
        id: Date.now().toString(),
        name: messageName,
        message: messageText,
        recipients: recipients.map(r => r.phoneNumber),
        deviceId: selectedDevice,
        deviceName: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`,
        status: scheduleEnabled && scheduledDateTime ? 'QUEUED' : 'DRAFT',
        totalRecipients: recipients.length,
        sentCount: 0,
        failedCount: 0,
        scheduledAt: scheduleEnabled && scheduledDateTime ? scheduledDateTime : undefined,
        createdAt: new Date().toISOString(),
        messageType,
        attachmentUrl: messageType !== 'text' ? attachmentUrl : undefined,
        priority
      }

      setBulkMessages([newBulkMessage, ...bulkMessages])
      
      notifications.show({
        title: 'Bulk Message Created',
        message: `Campaign "${messageName}" created with ${recipients.length} recipients`,
        color: 'green'
      })

      // Reset form
      setMessageName('')
      setMessageText('')
      setAttachmentUrl('')
      setRecipients([])
      setScheduleEnabled(false)
      setScheduledDateTime('')
      closeCreateModal()
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to create bulk message campaign',
        color: 'red'
      })
    }
  }

  const sendBulkMessage = async (messageId: string) => {
    const message = bulkMessages.find(m => m.id === messageId)
    if (!message) return

    try {
      // Update status to sending
      setBulkMessages(prev => prev.map(m => 
        m.id === messageId ? { ...m, status: 'SENDING' as const } : m
      ))

      notifications.show({
        title: 'Sending Started',
        message: `Sending "${message.name}" to ${message.totalRecipients} recipients`,
        color: 'blue'
      })

      // Simulate sending with random delay between messages
      let sentCount = 0
      const sendNext = () => {
        sentCount++
        setSendingProgress((sentCount / message.totalRecipients) * 100)
        
        setBulkMessages(prev => prev.map(m => 
          m.id === messageId ? { ...m, sentCount } : m
        ))

        if (sentCount >= message.totalRecipients) {
          setSendingProgress(0)
          
          setBulkMessages(prev => prev.map(m => 
            m.id === messageId ? { 
              ...m, 
              status: 'COMPLETED' as const, 
              sentCount: message.totalRecipients 
            } : m
          ))

          notifications.show({
            title: 'Sending Complete',
            message: `"${message.name}" sent to all ${message.totalRecipients} recipients`,
            color: 'green'
          })
        } else {
          // Random delay between minDelay and maxDelay
          const randomDelay = Math.random() * (maxDelay - minDelay) + minDelay
          setTimeout(sendNext, randomDelay * 1000)
        }
      }
      
      // Start sending
      sendNext()
    } catch (error) {
      setBulkMessages(prev => prev.map(m => 
        m.id === messageId ? { ...m, status: 'FAILED' as const } : m
      ))
      
      notifications.show({
        title: 'Sending Failed',
        message: 'Failed to send bulk message',
        color: 'red'
      })
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'DRAFT': return 'gray'
      case 'QUEUED': return 'blue'
      case 'SENDING': return 'yellow'
      case 'COMPLETED': return 'green'
      case 'FAILED': return 'red'
      default: return 'gray'
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'LOW': return 'gray'
      case 'NORMAL': return 'blue'
      case 'HIGH': return 'orange'
      case 'URGENT': return 'red'
      default: return 'blue'
    }
  }

  if (loading) {
    return <LoadingOverlay visible />
  }

  return (
    <div>
      <CustomerHeader 
        title="Bulk Messaging"
        subtitle="Create and manage bulk WhatsApp campaigns for multiple recipients"
        badge={{ label: 'Campaign Manager', color: 'purple' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Stats Cards */}
          <Grid>
            <Grid.Col span={{ base: 12, sm: 6, md: 3 }}>
              <Card withBorder padding="lg" style={{ backgroundColor: '#e8f5e8' }}>
                <Group gap="sm">
                  <IconUsers size={24} color="#25D366" />
                  <div>
                    <Text size="xs" c="dimmed">Total Campaigns</Text>
                    <Text size="lg" fw={600}>{bulkMessages.length}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 12, sm: 6, md: 3 }}>
              <Card withBorder padding="lg" style={{ backgroundColor: '#f0f8ff' }}>
                <Group gap="sm">
                  <IconSend size={24} color="#1976d2" />
                  <div>
                    <Text size="xs" c="dimmed">Messages Sent</Text>
                    <Text size="lg" fw={600}>
                      {bulkMessages.reduce((sum, m) => sum + m.sentCount, 0)}
                    </Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 12, sm: 6, md: 3 }}>
              <Card withBorder padding="lg" style={{ backgroundColor: '#fff5f5' }}>
                <Group gap="sm">
                  <IconX size={24} color="#d32f2f" />
                  <div>
                    <Text size="xs" c="dimmed">Failed Messages</Text>
                    <Text size="lg" fw={600}>
                      {bulkMessages.reduce((sum, m) => sum + m.failedCount, 0)}
                    </Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 12, sm: 6, md: 3 }}>
              <Card withBorder padding="lg" style={{ backgroundColor: '#f3e5f5' }}>
                <Group gap="sm">
                  <IconBrandWhatsapp size={24} color="#25D366" />
                  <div>
                    <Text size="xs" c="dimmed">Active Devices</Text>
                    <Text size="lg" fw={600}>{devices.length}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
          </Grid>

          {/* Main Content */}
          <Tabs value={activeTab} onChange={(value) => setActiveTab(value || 'create')}>
            <Tabs.List>
              <Tabs.Tab value="create" leftSection={<IconPlus size="1rem" />}>
                Create Campaign
              </Tabs.Tab>
              <Tabs.Tab value="campaigns" leftSection={<IconMessage size="1rem" />}>
                My Campaigns ({bulkMessages.length})
              </Tabs.Tab>
            </Tabs.List>

            <Tabs.Panel value="create" pt="lg">
              <Grid>
                <Grid.Col span={{ base: 12, md: 8 }}>
                  <Card withBorder padding="lg">
                    <Title order={3} mb="lg">Create Bulk Message Campaign</Title>
                    <Stack gap="md">
                      {/* Campaign Details */}
                      <TextInput
                        label="Campaign Name"
                        placeholder="Enter campaign name (e.g., 'Welcome Series', 'Product Launch')"
                        value={messageName}
                        onChange={(e) => setMessageName(e.target.value)}
                        required
                      />

                      <Select
                        label="Select Device"
                        placeholder="Choose a connected device"
                        data={devices.map(device => ({
                          value: device.id,
                          label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`
                        }))}
                        value={selectedDevice}
                        onChange={(value) => setSelectedDevice(value || '')}
                        leftSection={<IconBrandWhatsapp size="1rem" color="#25d366" />}
                        disabled={devices.length === 0}
                        required
                      />

                      <Select
                        label="Message Type"
                        data={[
                          { value: 'text', label: '📝 Text Message' },
                          { value: 'image', label: '📸 Image Attachment' },
                          { value: 'document', label: '📄 Document Attachment' }
                        ]}
                        value={messageType}
                        onChange={(value) => setMessageType(value as any || 'text')}
                      />

                      <Textarea
                        label="Message Content"
                        placeholder="Enter your bulk message here..."
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        minRows={4}
                        maxRows={8}
                        autosize
                        required
                      />

                      {messageType !== 'text' && (
                        <TextInput
                          label={`${messageType === 'image' ? 'Image' : 'Document'} URL`}
                          placeholder={`Enter ${messageType} URL`}
                          value={attachmentUrl}
                          onChange={(e) => setAttachmentUrl(e.target.value)}
                        />
                      )}

                      <Select
                        label="Priority"
                        data={[
                          { value: 'LOW', label: 'Low Priority' },
                          { value: 'NORMAL', label: 'Normal Priority' },
                          { value: 'HIGH', label: 'High Priority' },
                          { value: 'URGENT', label: 'Urgent Priority' }
                        ]}
                        value={priority}
                        onChange={(value) => setPriority(value as any || 'NORMAL')}
                      />

                      <Grid>
                        <Grid.Col span={6}>
                          <NumberInput
                            label="Min Delay (seconds)"
                            description="Minimum delay between messages"
                            value={minDelay}
                            onChange={(value) => setMinDelay(Number(value) || 2)}
                            min={1}
                            max={30}
                          />
                        </Grid.Col>
                        <Grid.Col span={6}>
                          <NumberInput
                            label="Max Delay (seconds)"
                            description="Maximum delay between messages"
                            value={maxDelay}
                            onChange={(value) => setMaxDelay(Number(value) || 5)}
                            min={minDelay + 1}
                            max={60}
                          />
                        </Grid.Col>
                      </Grid>
                      <Alert color="blue" variant="light" style={{ marginTop: '8px' }}>
                        <Text size="xs">
                          ⏱️ Random delay between {minDelay}-{maxDelay} seconds helps avoid rate limiting and appears more natural
                        </Text>
                      </Alert>

                      <Switch
                        label="Schedule for later"
                        description="Send this campaign at a specific time"
                        checked={scheduleEnabled}
                        onChange={(event) => setScheduleEnabled(event.currentTarget.checked)}
                      />

                      {scheduleEnabled && (
                        <TextInput
                          label="Schedule Date & Time"
                          type="datetime-local"
                          value={scheduledDateTime}
                          onChange={(e) => setScheduledDateTime(e.target.value)}
                          min={new Date().toISOString().slice(0, 16)}
                        />
                      )}

                      <Button
                        leftSection={<IconPlus size="1rem" />}
                        onClick={createBulkMessage}
                        disabled={!messageName || !messageText || recipients.length === 0 || !selectedDevice}
                        size="md"
                        variant="gradient"
                        gradient={{ from: 'purple', to: 'grape', deg: 45 }}
                      >
                        Create Campaign ({recipients.length} recipients)
                      </Button>
                    </Stack>
                  </Card>
                </Grid.Col>

                <Grid.Col span={{ base: 12, md: 4 }}>
                  <Stack gap="md">
                    {/* Recipients Management */}
                    <Card withBorder padding="md">
                      <Title order={5} mb="md">
                        Recipients ({recipients.length})
                      </Title>

                      <Stack gap="sm">
                        <Group gap="sm">
                          <TextInput
                            placeholder="Phone number"
                            value={newRecipient}
                            onChange={(e) => setNewRecipient(e.target.value)}
                            flex={1}
                          />
                          <TextInput
                            placeholder="Name (optional)"
                            value={newRecipientName}
                            onChange={(e) => setNewRecipientName(e.target.value)}
                            flex={1}
                          />
                          <ActionIcon
                            variant="filled"
                            onClick={addRecipient}
                            disabled={!newRecipient.trim()}
                          >
                            <IconPlus size="1rem" />
                          </ActionIcon>
                        </Group>

                        <FileInput
                          label="Upload CSV"
                          placeholder="Select CSV file"
                          accept=".csv"
                          value={csvFile}
                          onChange={(file) => {
                            setCsvFile(file)
                            if (file) handleCsvUpload(file)
                          }}
                          leftSection={<IconFile size="1rem" />}
                        />

                        <Text size="xs" c="dimmed">
                          CSV format: phone,name (one per line)
                        </Text>

                        {recipients.length > 0 && (
                          <div style={{ maxHeight: 200, overflowY: 'auto' }}>
                            <Stack gap={4}>
                              {recipients.map((recipient) => (
                                <Group key={recipient.id} justify="space-between" gap="sm">
                                  <div>
                                    <Text size="sm" fw={500}>{recipient.phoneNumber}</Text>
                                    {recipient.name && (
                                      <Text size="xs" c="dimmed">{recipient.name}</Text>
                                    )}
                                  </div>
                                  <ActionIcon
                                    variant="subtle"
                                    color="red"
                                    size="sm"
                                    onClick={() => removeRecipient(recipient.id)}
                                  >
                                    <IconTrash size="0.8rem" />
                                  </ActionIcon>
                                </Group>
                              ))}
                            </Stack>
                          </div>
                        )}
                      </Stack>
                    </Card>

                    {/* Device Status */}
                    {devices.length > 0 ? (
                      <Card withBorder padding="md" style={{ backgroundColor: '#e8f5e8' }}>
                        <Title order={6} mb="sm">✅ Device Status</Title>
                        <Text size="xs" c="green">
                          {devices.length} connected device{devices.length !== 1 ? 's' : ''} ready for bulk messaging
                        </Text>
                      </Card>
                    ) : (
                      <Alert icon={<IconX size="1rem" />} color="red">
                        <Text size="sm">No connected devices</Text>
                        <Text size="xs">Connect a WhatsApp device first</Text>
                      </Alert>
                    )}
                  </Stack>
                </Grid.Col>
              </Grid>
            </Tabs.Panel>

            <Tabs.Panel value="campaigns" pt="lg">
              <Stack gap="md">
                <Group justify="space-between">
                  <Text size="lg" fw={600}>Your Bulk Message Campaigns</Text>
                  <Button
                    leftSection={<IconRefresh size="1rem" />}
                    onClick={fetchBulkMessages}
                    variant="light"
                  >
                    Refresh
                  </Button>
                </Group>

                {sendingProgress > 0 && (
                  <Card withBorder padding="md" style={{ backgroundColor: '#fff3cd' }}>
                    <Text size="sm" mb="sm">Sending in progress...</Text>
                    <Progress value={sendingProgress} animated />
                  </Card>
                )}

                {bulkMessages.length > 0 ? (
                  <Card withBorder padding="lg">
                    <Table striped highlightOnHover>
                      <Table.Thead>
                        <Table.Tr>
                          <Table.Th>Campaign Name</Table.Th>
                          <Table.Th>Device</Table.Th>
                          <Table.Th>Recipients</Table.Th>
                          <Table.Th>Status</Table.Th>
                          <Table.Th>Progress</Table.Th>
                          <Table.Th>Priority</Table.Th>
                          <Table.Th>Scheduled</Table.Th>
                          <Table.Th>Actions</Table.Th>
                        </Table.Tr>
                      </Table.Thead>
                      <Table.Tbody>
                        {bulkMessages.map((message) => (
                          <Table.Tr key={message.id}>
                            <Table.Td>
                              <div>
                                <Text size="sm" fw={500}>{message.name}</Text>
                                <Text size="xs" c="dimmed" lineClamp={1}>
                                  {message.message.length > 50 
                                    ? message.message.substring(0, 50) + '...' 
                                    : message.message
                                  }
                                </Text>
                              </div>
                            </Table.Td>
                            <Table.Td>
                              <Text size="sm">{message.deviceName}</Text>
                            </Table.Td>
                            <Table.Td>
                              <Text size="sm">{message.totalRecipients}</Text>
                            </Table.Td>
                            <Table.Td>
                              <Badge 
                                color={getStatusColor(message.status)} 
                                size="sm"
                                variant={message.status === 'SENDING' ? 'filled' : 'light'}
                              >
                                {message.status}
                              </Badge>
                            </Table.Td>
                            <Table.Td>
                              <Text size="sm">
                                {message.sentCount}/{message.totalRecipients}
                                {message.failedCount > 0 && (
                                  <span style={{ color: 'red' }}>
                                    {' '}({message.failedCount} failed)
                                  </span>
                                )}
                              </Text>
                            </Table.Td>
                            <Table.Td>
                              <Badge 
                                color={getPriorityColor(message.priority)} 
                                size="xs"
                                variant="light"
                              >
                                {message.priority}
                              </Badge>
                            </Table.Td>
                            <Table.Td>
                              <Text size="xs" c="dimmed">
                                {message.scheduledAt 
                                  ? new Date(message.scheduledAt).toLocaleString()
                                  : 'Immediate'
                                }
                              </Text>
                            </Table.Td>
                            <Table.Td>
                              <Group gap="xs">
                                {message.status === 'DRAFT' && (
                                  <ActionIcon
                                    variant="filled"
                                    color="green"
                                    onClick={() => sendBulkMessage(message.id)}
                                    title="Send Now"
                                  >
                                    <IconPlayerPlay size="1rem" />
                                  </ActionIcon>
                                )}
                                <ActionIcon
                                  variant="subtle"
                                  color="blue"
                                  onClick={() => {
                                    setSelectedMessage(message)
                                    openDetailsModal()
                                  }}
                                  title="View Details"
                                >
                                  <IconEdit size="1rem" />
                                </ActionIcon>
                                {message.status !== 'SENDING' && (
                                  <ActionIcon
                                    variant="subtle"
                                    color="red"
                                    title="Delete Campaign"
                                  >
                                    <IconTrash size="1rem" />
                                  </ActionIcon>
                                )}
                              </Group>
                            </Table.Td>
                          </Table.Tr>
                        ))}
                      </Table.Tbody>
                    </Table>
                  </Card>
                ) : (
                  <Alert icon={<IconMessage size="1rem" />} color="blue">
                    <Text size="sm" fw={500}>No bulk campaigns created yet</Text>
                    <Text size="xs">Switch to the "Create Campaign" tab to get started</Text>
                  </Alert>
                )}
              </Stack>
            </Tabs.Panel>
          </Tabs>

          {/* Details Modal */}
          <Modal
            opened={detailsModalOpened}
            onClose={closeDetailsModal}
            title={`Campaign Details: ${selectedMessage?.name}`}
            size="lg"
          >
            {selectedMessage && (
              <Stack gap="md">
                <Group gap="md">
                  <Badge color={getStatusColor(selectedMessage.status)} size="lg">
                    {selectedMessage.status}
                  </Badge>
                  <Badge color={getPriorityColor(selectedMessage.priority)} size="lg">
                    {selectedMessage.priority} PRIORITY
                  </Badge>
                </Group>

                <div>
                  <Text size="sm" fw={500} mb="xs">Message:</Text>
                  <Text size="sm" style={{ backgroundColor: '#f8f9fa', padding: '8px', borderRadius: '4px' }}>
                    {selectedMessage.message}
                  </Text>
                </div>

                <Group gap="lg">
                  <div>
                    <Text size="sm" fw={500}>Total Recipients</Text>
                    <Text size="xl" fw={700}>{selectedMessage.totalRecipients}</Text>
                  </div>
                  <div>
                    <Text size="sm" fw={500} c="green">Sent</Text>
                    <Text size="xl" fw={700} c="green">{selectedMessage.sentCount}</Text>
                  </div>
                  <div>
                    <Text size="sm" fw={500} c="red">Failed</Text>
                    <Text size="xl" fw={700} c="red">{selectedMessage.failedCount}</Text>
                  </div>
                </Group>

                <div>
                  <Text size="sm" fw={500} mb="xs">Device:</Text>
                  <Text size="sm">{selectedMessage.deviceName}</Text>
                </div>

                <div>
                  <Text size="sm" fw={500} mb="xs">Created:</Text>
                  <Text size="sm">{new Date(selectedMessage.createdAt).toLocaleString()}</Text>
                </div>

                {selectedMessage.scheduledAt && (
                  <div>
                    <Text size="sm" fw={500} mb="xs">Scheduled:</Text>
                    <Text size="sm">{new Date(selectedMessage.scheduledAt).toLocaleString()}</Text>
                  </div>
                )}
              </Stack>
            )}
          </Modal>
        </Stack>
      </Container>
    </div>
  )
}