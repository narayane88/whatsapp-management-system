'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  TextInput,
  Select,
  Text,
  Title,
  Badge,
  Table,
  ActionIcon,
  Modal,
  Alert,
  LoadingOverlay,
  Grid,
  Textarea,
  Avatar
} from '@mantine/core'
import {
  IconBrandWhatsapp,
  IconUsers,
  IconSearch,
  IconEye,
  IconRefresh,
  IconPlus,
  IconTrash,
  IconEdit,
  IconMessage,
  IconUserPlus,
  IconUserMinus,
  IconSettings,
  IconCrown,
  IconShield
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import { useDisclosure } from '@mantine/hooks'
import { useForm } from '@mantine/form'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface WhatsAppGroup {
  id: string
  deviceId: string
  deviceName: string
  groupId: string
  name: string
  subject: string
  description?: string
  participantCount: number
  adminCount: number
  createdAt: string
  lastActivity: string
  isAdmin: boolean
  groupInviteCode?: string
  announcement: boolean
  ephemeralEnabled: boolean
  profilePictureUrl?: string
}

interface GroupParticipant {
  id: string
  phoneNumber: string
  name?: string
  isAdmin: boolean
  joinedAt: string
  lastSeen?: string
}

interface ConnectedDevice {
  id: string
  accountName: string
  phoneNumber?: string
  status: string
  serverName: string
}

interface NewGroupForm {
  deviceId: string
  name: string
  description: string
  participants: string[]
}

export default function WhatsAppGroupsPage() {
  const [groups, setGroups] = useState<WhatsAppGroup[]>([])
  const [devices, setDevices] = useState<ConnectedDevice[]>([])
  const [participants, setParticipants] = useState<GroupParticipant[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDevice, setFilterDevice] = useState('')
  const [selectedGroup, setSelectedGroup] = useState<WhatsAppGroup | null>(null)
  const [detailsOpened, { open: openDetails, close: closeDetails }] = useDisclosure(false)
  const [createOpened, { open: openCreate, close: closeCreate }] = useDisclosure(false)
  const [participantsOpened, { open: openParticipants, close: closeParticipants }] = useDisclosure(false)

  const form = useForm<NewGroupForm>({
    initialValues: {
      deviceId: '',
      name: '',
      description: '',
      participants: []
    },
    validate: {
      deviceId: (value) => (!value ? 'Device is required' : null),
      name: (value) => (!value ? 'Group name is required' : null)
    }
  })

  useEffect(() => {
    fetchDevices()
    fetchGroups()
  }, [filterDevice, searchTerm])

  const fetchDevices = async () => {
    try {
      const response = await fetch('/api/customer/host/connections')
      if (response.ok) {
        const allDevices = await response.json()
        const connectedDevices = allDevices.filter((device: any) => device.status === 'CONNECTED')
        setDevices(connectedDevices)
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    }
  }

  const fetchGroups = async () => {
    try {
      setLoading(true)
      // Mock data - replace with actual API call
      const mockGroups: WhatsAppGroup[] = [
        {
          id: '1',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          groupId: 'group_001',
          name: 'Customer Support Team',
          subject: 'Customer Support Team',
          description: 'Internal team for handling customer queries and support',
          participantCount: 12,
          adminCount: 3,
          createdAt: new Date(Date.now() - 7200000).toISOString(),
          lastActivity: new Date(Date.now() - 1800000).toISOString(),
          isAdmin: true,
          groupInviteCode: 'https://chat.whatsapp.com/ABC123',
          announcement: false,
          ephemeralEnabled: false,
          profilePictureUrl: 'https://via.placeholder.com/40'
        },
        {
          id: '2',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          groupId: 'group_002',
          name: 'Product Updates',
          subject: 'Product Updates',
          description: 'Get notified about new features and product updates',
          participantCount: 28,
          adminCount: 2,
          createdAt: new Date(Date.now() - 86400000).toISOString(),
          lastActivity: new Date(Date.now() - 3600000).toISOString(),
          isAdmin: false,
          announcement: true,
          ephemeralEnabled: true,
          profilePictureUrl: 'https://via.placeholder.com/40'
        },
        {
          id: '3',
          deviceId: 'device1',
          deviceName: '(+919960589622) - Primary Server',
          groupId: 'group_003',
          name: 'Sales Team',
          subject: 'Sales Team',
          participantCount: 8,
          adminCount: 1,
          createdAt: new Date(Date.now() - 172800000).toISOString(),
          lastActivity: new Date(Date.now() - 7200000).toISOString(),
          isAdmin: true,
          announcement: false,
          ephemeralEnabled: false
        }
      ]
      
      setGroups(mockGroups)
    } catch (error) {
      console.error('Error fetching groups:', error)
      notifications.show({
        title: 'Error',
        message: 'Failed to load WhatsApp groups',
        color: 'red'
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchGroupParticipants = async (groupId: string) => {
    try {
      // Mock participants data - replace with actual API call
      const mockParticipants: GroupParticipant[] = [
        {
          id: '1',
          phoneNumber: '+919876543210',
          name: 'John Admin',
          isAdmin: true,
          joinedAt: new Date(Date.now() - 86400000).toISOString(),
          lastSeen: new Date(Date.now() - 3600000).toISOString()
        },
        {
          id: '2',
          phoneNumber: '+919876543211',
          name: 'Sarah Support',
          isAdmin: false,
          joinedAt: new Date(Date.now() - 72000000).toISOString(),
          lastSeen: new Date(Date.now() - 1800000).toISOString()
        },
        {
          id: '3',
          phoneNumber: '+919876543212',
          name: 'Mike Team Lead',
          isAdmin: true,
          joinedAt: new Date(Date.now() - 144000000).toISOString(),
          lastSeen: new Date(Date.now() - 7200000).toISOString()
        },
        {
          id: '4',
          phoneNumber: '+919876543213',
          isAdmin: false,
          joinedAt: new Date(Date.now() - 36000000).toISOString(),
          lastSeen: new Date(Date.now() - 900000).toISOString()
        }
      ]
      
      setParticipants(mockParticipants)
    } catch (error) {
      console.error('Error fetching group participants:', error)
    }
  }

  const createGroup = async (values: NewGroupForm) => {
    try {
      const device = devices.find(d => d.id === values.deviceId)
      if (!device) {
        notifications.show({
          title: 'Error',
          message: 'Selected device not found',
          color: 'red'
        })
        return
      }

      const newGroup: WhatsAppGroup = {
        id: Date.now().toString(),
        deviceId: values.deviceId,
        deviceName: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`,
        groupId: `group_${Date.now()}`,
        name: values.name,
        subject: values.name,
        description: values.description,
        participantCount: values.participants.length + 1, // +1 for creator
        adminCount: 1,
        createdAt: new Date().toISOString(),
        lastActivity: new Date().toISOString(),
        isAdmin: true,
        announcement: false,
        ephemeralEnabled: false
      }

      setGroups(prev => [newGroup, ...prev])
      
      notifications.show({
        title: 'Group Created',
        message: `WhatsApp group "${values.name}" created successfully`,
        color: 'green'
      })

      form.reset()
      closeCreate()
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to create WhatsApp group',
        color: 'red'
      })
    }
  }

  const viewGroupDetails = (group: WhatsAppGroup) => {
    setSelectedGroup(group)
    openDetails()
  }

  const viewGroupParticipants = (group: WhatsAppGroup) => {
    setSelectedGroup(group)
    fetchGroupParticipants(group.groupId)
    openParticipants()
  }

  const sendMessageToGroup = (group: WhatsAppGroup) => {
    notifications.show({
      title: 'Message Group',
      message: `Redirecting to send message to "${group.name}"`,
      color: 'blue'
    })
    // In real implementation: router.push(`/customer/whatsapp/send?groupId=${group.groupId}`)
  }

  const leaveGroup = async (groupId: string) => {
    if (!confirm('Are you sure you want to leave this group?')) {
      return
    }

    setGroups(prev => prev.filter(g => g.id !== groupId))
    
    notifications.show({
      title: 'Left Group',
      message: 'You have left the WhatsApp group',
      color: 'yellow'
    })
  }

  const filteredGroups = groups.filter(group => {
    const matchesSearch = group.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         group.description?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDevice = !filterDevice || group.deviceId === filterDevice

    return matchesSearch && matchesDevice
  })

  const getGroupStats = () => {
    const total = groups.length
    const adminGroups = groups.filter(g => g.isAdmin).length
    const totalParticipants = groups.reduce((sum, g) => sum + g.participantCount, 0)
    const announcementGroups = groups.filter(g => g.announcement).length

    return { total, adminGroups, totalParticipants, announcementGroups }
  }

  const stats = getGroupStats()

  if (loading) {
    return <LoadingOverlay visible />
  }

  return (
    <div>
      <CustomerHeader 
        title="WhatsApp Groups"
        subtitle="Manage your WhatsApp group chats, participants, and settings"
        badge={{ label: 'Group Manager', color: 'grape' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Stats Cards */}
          <Grid>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#f3e5f5' }}>
                <Group gap="sm">
                  <IconUsers size={20} color="#9c27b0" />
                  <div>
                    <Text size="xs" c="dimmed">Total Groups</Text>
                    <Text size="lg" fw={600}>{stats.total}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#fff3e0' }}>
                <Group gap="sm">
                  <IconCrown size={20} color="#ff9800" />
                  <div>
                    <Text size="xs" c="dimmed">Admin Groups</Text>
                    <Text size="lg" fw={600}>{stats.adminGroups}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e8f5e8' }}>
                <Group gap="sm">
                  <IconUserPlus size={20} color="#4caf50" />
                  <div>
                    <Text size="xs" c="dimmed">Total Members</Text>
                    <Text size="lg" fw={600}>{stats.totalParticipants}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e3f2fd' }}>
                <Group gap="sm">
                  <IconShield size={20} color="#2196f3" />
                  <div>
                    <Text size="xs" c="dimmed">Announcements</Text>
                    <Text size="lg" fw={600}>{stats.announcementGroups}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
          </Grid>

          {/* Controls */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>Manage Groups</Title>
              <Button
                leftSection={<IconPlus size="1rem" />}
                onClick={openCreate}
                disabled={devices.length === 0}
              >
                Create New Group
              </Button>
            </Group>

            <Grid>
              <Grid.Col span={{ base: 12, md: 4 }}>
                <TextInput
                  placeholder="Search groups..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  leftSection={<IconSearch size="1rem" />}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 4 }}>
                <Select
                  placeholder="Filter by device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'}`
                  }))}
                  value={filterDevice}
                  onChange={(value) => setFilterDevice(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 4 }}>
                <Button
                  variant="light"
                  onClick={fetchGroups}
                  fullWidth
                  leftSection={<IconRefresh size="1rem" />}
                >
                  Refresh
                </Button>
              </Grid.Col>
            </Grid>
          </Card>

          {/* Groups Table */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>WhatsApp Groups ({filteredGroups.length})</Title>
            </Group>

            {filteredGroups.length > 0 ? (
              <Table striped highlightOnHover>
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>Group</Table.Th>
                    <Table.Th>Participants</Table.Th>
                    <Table.Th>Role</Table.Th>
                    <Table.Th>Settings</Table.Th>
                    <Table.Th>Device</Table.Th>
                    <Table.Th>Last Activity</Table.Th>
                    <Table.Th>Actions</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>
                  {filteredGroups.map((group) => (
                    <Table.Tr key={group.id}>
                      <Table.Td>
                        <Group gap="sm">
                          <Avatar 
                            src={group.profilePictureUrl} 
                            size="sm"
                            color="grape"
                          >
                            <IconUsers size="1rem" />
                          </Avatar>
                          <div>
                            <Text size="sm" fw={500}>{group.name}</Text>
                            {group.description && (
                              <Text size="xs" c="dimmed" lineClamp={1}>
                                {group.description}
                              </Text>
                            )}
                          </div>
                        </Group>
                      </Table.Td>
                      <Table.Td>
                        <div>
                          <Text size="sm">{group.participantCount} members</Text>
                          <Text size="xs" c="dimmed">{group.adminCount} admin{group.adminCount !== 1 ? 's' : ''}</Text>
                        </div>
                      </Table.Td>
                      <Table.Td>
                        <Badge 
                          color={group.isAdmin ? 'orange' : 'blue'} 
                          size="sm"
                          variant="light"
                          leftSection={group.isAdmin ? <IconCrown size="0.8rem" /> : <IconUsers size="0.8rem" />}
                        >
                          {group.isAdmin ? 'Admin' : 'Member'}
                        </Badge>
                      </Table.Td>
                      <Table.Td>
                        <Stack gap={2}>
                          {group.announcement && (
                            <Badge size="xs" color="blue" variant="light">
                              Announcement Only
                            </Badge>
                          )}
                          {group.ephemeralEnabled && (
                            <Badge size="xs" color="yellow" variant="light">
                              Disappearing Messages
                            </Badge>
                          )}
                          {!group.announcement && !group.ephemeralEnabled && (
                            <Text size="xs" c="dimmed">Standard</Text>
                          )}
                        </Stack>
                      </Table.Td>
                      <Table.Td>
                        <Text size="xs" c="dimmed">{group.deviceName}</Text>
                      </Table.Td>
                      <Table.Td>
                        <Text size="xs">
                          {new Date(group.lastActivity).toLocaleString()}
                        </Text>
                      </Table.Td>
                      <Table.Td>
                        <Group gap="xs">
                          <ActionIcon
                            variant="subtle"
                            color="blue"
                            onClick={() => viewGroupDetails(group)}
                            title="View Details"
                          >
                            <IconEye size="1rem" />
                          </ActionIcon>
                          <ActionIcon
                            variant="subtle"
                            color="grape"
                            onClick={() => viewGroupParticipants(group)}
                            title="View Participants"
                          >
                            <IconUsers size="1rem" />
                          </ActionIcon>
                          <ActionIcon
                            variant="subtle"
                            color="green"
                            onClick={() => sendMessageToGroup(group)}
                            title="Send Message"
                          >
                            <IconMessage size="1rem" />
                          </ActionIcon>
                          <ActionIcon
                            variant="subtle"
                            color="red"
                            onClick={() => leaveGroup(group.id)}
                            title="Leave Group"
                          >
                            <IconTrash size="1rem" />
                          </ActionIcon>
                        </Group>
                      </Table.Td>
                    </Table.Tr>
                  ))}
                </Table.Tbody>
              </Table>
            ) : (
              <Alert color="blue">
                <Text size="sm" fw={500}>No WhatsApp groups found</Text>
                <Text size="xs">
                  {devices.length === 0 ? 
                    'Connect a WhatsApp device first to see your groups.' :
                    searchTerm || filterDevice ? 
                    'Try adjusting your search or filters.' : 
                    'No groups available. Create a new group to get started.'}
                </Text>
              </Alert>
            )}
          </Card>

          {/* Create Group Modal */}
          <Modal
            opened={createOpened}
            onClose={closeCreate}
            title="Create WhatsApp Group"
            size="lg"
          >
            <form onSubmit={form.onSubmit(createGroup)}>
              <Stack gap="md">
                <Select
                  label="Device"
                  placeholder="Select connected device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`
                  }))}
                  {...form.getInputProps('deviceId')}
                  required
                />

                <TextInput
                  label="Group Name"
                  placeholder="Enter group name"
                  {...form.getInputProps('name')}
                  required
                />

                <Textarea
                  label="Group Description"
                  placeholder="Enter group description (optional)"
                  {...form.getInputProps('description')}
                  rows={3}
                />

                <Textarea
                  label="Participants (Phone Numbers)"
                  placeholder="Enter phone numbers separated by commas or new lines"
                  description="Format: +919876543210, +919876543211"
                  rows={4}
                  onChange={(e) => {
                    const participants = e.target.value
                      .split(/[,\n]/)
                      .map(p => p.trim())
                      .filter(p => p.length > 0)
                    form.setFieldValue('participants', participants)
                  }}
                />

                <Group justify="flex-end">
                  <Button variant="subtle" onClick={closeCreate}>
                    Cancel
                  </Button>
                  <Button type="submit" leftSection={<IconPlus size="1rem" />}>
                    Create Group
                  </Button>
                </Group>
              </Stack>
            </form>
          </Modal>

          {/* Group Details Modal */}
          <Modal
            opened={detailsOpened}
            onClose={closeDetails}
            title="Group Details"
            size="lg"
          >
            {selectedGroup && (
              <Stack gap="md">
                <Group gap="md">
                  <Avatar 
                    src={selectedGroup.profilePictureUrl} 
                    size="lg"
                    color="grape"
                  >
                    <IconUsers size="1.5rem" />
                  </Avatar>
                  <div>
                    <Text size="lg" fw={600}>{selectedGroup.name}</Text>
                    <Badge 
                      color={selectedGroup.isAdmin ? 'orange' : 'blue'} 
                      variant="light"
                    >
                      {selectedGroup.isAdmin ? 'Admin' : 'Member'}
                    </Badge>
                  </div>
                </Group>

                {selectedGroup.description && (
                  <div>
                    <Text size="sm" fw={500} mb="xs">Description:</Text>
                    <Text size="sm" style={{ 
                      backgroundColor: '#f8f9fa', 
                      padding: '8px', 
                      borderRadius: '4px' 
                    }}>
                      {selectedGroup.description}
                    </Text>
                  </div>
                )}

                <Grid>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Participants:</Text>
                    <Text size="sm">{selectedGroup.participantCount}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Admins:</Text>
                    <Text size="sm">{selectedGroup.adminCount}</Text>
                  </Grid.Col>
                </Grid>

                <Grid>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Created:</Text>
                    <Text size="sm">{new Date(selectedGroup.createdAt).toLocaleString()}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Last Activity:</Text>
                    <Text size="sm">{new Date(selectedGroup.lastActivity).toLocaleString()}</Text>
                  </Grid.Col>
                </Grid>

                <div>
                  <Text size="sm" fw={500}>Device:</Text>
                  <Text size="sm">{selectedGroup.deviceName}</Text>
                </div>

                {selectedGroup.groupInviteCode && (
                  <div>
                    <Text size="sm" fw={500} mb="xs">Invite Link:</Text>
                    <Text size="xs" family="monospace" c="blue" style={{ wordBreak: 'break-all' }}>
                      {selectedGroup.groupInviteCode}
                    </Text>
                  </div>
                )}

                <div>
                  <Text size="sm" fw={500} mb="xs">Settings:</Text>
                  <Group gap="xs">
                    <Badge color="blue" size="sm" variant="light">
                      {selectedGroup.announcement ? 'Announcement Only' : 'All Members Can Send'}
                    </Badge>
                    <Badge color="yellow" size="sm" variant="light">
                      {selectedGroup.ephemeralEnabled ? 'Disappearing Messages ON' : 'Disappearing Messages OFF'}
                    </Badge>
                  </Group>
                </div>

                <div>
                  <Text size="sm" fw={500}>Group ID:</Text>
                  <Text size="xs" family="monospace" c="dimmed">{selectedGroup.groupId}</Text>
                </div>
              </Stack>
            )}
          </Modal>

          {/* Group Participants Modal */}
          <Modal
            opened={participantsOpened}
            onClose={closeParticipants}
            title={`Group Participants - ${selectedGroup?.name}`}
            size="lg"
          >
            {selectedGroup && (
              <Stack gap="md">
                <Group justify="space-between">
                  <Text size="sm" c="dimmed">
                    {selectedGroup.participantCount} participants
                  </Text>
                  {selectedGroup.isAdmin && (
                    <Button size="xs" leftSection={<IconUserPlus size="0.8rem" />}>
                      Add Participant
                    </Button>
                  )}
                </Group>

                <Table>
                  <Table.Thead>
                    <Table.Tr>
                      <Table.Th>Participant</Table.Th>
                      <Table.Th>Role</Table.Th>
                      <Table.Th>Joined</Table.Th>
                      <Table.Th>Last Seen</Table.Th>
                      <Table.Th>Actions</Table.Th>
                    </Table.Tr>
                  </Table.Thead>
                  <Table.Tbody>
                    {participants.map((participant) => (
                      <Table.Tr key={participant.id}>
                        <Table.Td>
                          <div>
                            <Text size="sm" fw={500}>
                              {participant.name || participant.phoneNumber}
                            </Text>
                            {participant.name && (
                              <Text size="xs" c="dimmed">{participant.phoneNumber}</Text>
                            )}
                          </div>
                        </Table.Td>
                        <Table.Td>
                          <Badge 
                            color={participant.isAdmin ? 'orange' : 'blue'} 
                            size="xs"
                            variant="light"
                          >
                            {participant.isAdmin ? 'Admin' : 'Member'}
                          </Badge>
                        </Table.Td>
                        <Table.Td>
                          <Text size="xs">
                            {new Date(participant.joinedAt).toLocaleDateString()}
                          </Text>
                        </Table.Td>
                        <Table.Td>
                          <Text size="xs" c="dimmed">
                            {participant.lastSeen ? 
                              new Date(participant.lastSeen).toLocaleString() : 
                              'Never'
                            }
                          </Text>
                        </Table.Td>
                        <Table.Td>
                          {selectedGroup.isAdmin && (
                            <Group gap="xs">
                              <ActionIcon
                                variant="subtle"
                                color="green"
                                size="sm"
                                title="Send Message"
                              >
                                <IconMessage size="0.8rem" />
                              </ActionIcon>
                              <ActionIcon
                                variant="subtle"
                                color="red"
                                size="sm"
                                title="Remove from Group"
                              >
                                <IconUserMinus size="0.8rem" />
                              </ActionIcon>
                            </Group>
                          )}
                        </Table.Td>
                      </Table.Tr>
                    ))}
                  </Table.Tbody>
                </Table>
              </Stack>
            )}
          </Modal>
        </Stack>
      </Container>
    </div>
  )
}