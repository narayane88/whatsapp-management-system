'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  TextInput,
  Select,
  Text,
  Title,
  Badge,
  Grid,
  Alert,
  Switch,
  NumberInput,
  Textarea,
  Divider,
  ColorInput,
  SegmentedControl,
  Slider
} from '@mantine/core'
import {
  IconBrandWhatsapp,
  IconSettings,
  IconDeviceMobile,
  IconMessage,
  IconBell,
  IconShield,
  IconClock,
  IconRefresh,
  IconCheck,
  IconX,
  IconDownload,
  IconUpload,
  IconTrash,
  IconInfoCircle,
  IconPalette
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface WhatsAppSettings {
  // Device Settings
  autoReconnect: boolean
  connectionTimeout: number
  maxRetryAttempts: number
  qrCodeTimeout: number
  
  // Message Settings
  defaultMessageType: 'text' | 'image' | 'document'
  messageDelay: number
  enableReadReceipts: boolean
  enableTypingIndicator: boolean
  maxMessageLength: number
  
  // Notification Settings
  enableNotifications: boolean
  notificationSound: boolean
  desktopNotifications: boolean
  emailNotifications: boolean
  webhookUrl?: string
  
  // Security Settings
  enableEncryption: boolean
  sessionTimeout: number
  ipWhitelist: string[]
  twoFactorAuth: boolean
  
  // Automation Settings
  autoReply: boolean
  autoReplyMessage: string
  businessHours: {
    enabled: boolean
    start: string
    end: string
    timezone: string
  }
  
  // API Settings
  rateLimitPerMinute: number
  enableApiLogging: boolean
  logLevel: 'error' | 'warn' | 'info' | 'debug'
  
  // Appearance
  theme: 'light' | 'dark' | 'auto'
  accentColor: string
  compactMode: boolean
}

interface ConnectedDevice {
  id: string
  accountName: string
  phoneNumber?: string
  status: string
  serverName: string
}

export default function WhatsAppSettingsPage() {
  const [devices, setDevices] = useState<ConnectedDevice[]>([])
  const [selectedDevice, setSelectedDevice] = useState('')
  const [settings, setSettings] = useState<WhatsAppSettings>({
    // Device Settings
    autoReconnect: true,
    connectionTimeout: 30,
    maxRetryAttempts: 3,
    qrCodeTimeout: 60,
    
    // Message Settings
    defaultMessageType: 'text',
    messageDelay: 2,
    enableReadReceipts: true,
    enableTypingIndicator: true,
    maxMessageLength: 4096,
    
    // Notification Settings
    enableNotifications: true,
    notificationSound: true,
    desktopNotifications: false,
    emailNotifications: false,
    webhookUrl: '',
    
    // Security Settings
    enableEncryption: true,
    sessionTimeout: 60,
    ipWhitelist: [],
    twoFactorAuth: false,
    
    // Automation Settings
    autoReply: false,
    autoReplyMessage: 'Thank you for your message. We will get back to you soon.',
    businessHours: {
      enabled: false,
      start: '09:00',
      end: '18:00',
      timezone: 'Asia/Kolkata'
    },
    
    // API Settings
    rateLimitPerMinute: 60,
    enableApiLogging: true,
    logLevel: 'info',
    
    // Appearance
    theme: 'light',
    accentColor: '#25D366',
    compactMode: false
  })

  const [unsavedChanges, setUnsavedChanges] = useState(false)

  useEffect(() => {
    fetchDevices()
    loadSettings()
  }, [])

  const fetchDevices = async () => {
    try {
      const response = await fetch('/api/customer/host/connections')
      if (response.ok) {
        const allDevices = await response.json()
        setDevices(allDevices)
        if (allDevices.length > 0 && !selectedDevice) {
          setSelectedDevice(allDevices[0].id)
        }
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    }
  }

  const loadSettings = async () => {
    try {
      // In real implementation, load settings from API
      // For now, using defaults
    } catch (error) {
      console.error('Error loading settings:', error)
    }
  }

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }))
    setUnsavedChanges(true)
  }

  const updateNestedSetting = (parent: string, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [parent]: {
        ...(prev as any)[parent],
        [key]: value
      }
    }))
    setUnsavedChanges(true)
  }

  const saveSettings = async () => {
    try {
      // In real implementation, save to API
      notifications.show({
        title: 'Settings Saved',
        message: 'WhatsApp settings have been updated successfully',
        color: 'green'
      })
      setUnsavedChanges(false)
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to save settings',
        color: 'red'
      })
    }
  }

  const resetSettings = () => {
    if (confirm('Are you sure you want to reset all settings to default values?')) {
      loadSettings()
      setUnsavedChanges(false)
      notifications.show({
        title: 'Settings Reset',
        message: 'All settings have been reset to default values',
        color: 'blue'
      })
    }
  }

  const exportSettings = () => {
    const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'whatsapp-settings.json'
    a.click()
    URL.revokeObjectURL(url)
    
    notifications.show({
      title: 'Settings Exported',
      message: 'Settings have been exported to file',
      color: 'green'
    })
  }

  const importSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const importedSettings = JSON.parse(e.target?.result as string)
        setSettings(importedSettings)
        setUnsavedChanges(true)
        notifications.show({
          title: 'Settings Imported',
          message: 'Settings have been imported successfully',
          color: 'green'
        })
      } catch (error) {
        notifications.show({
          title: 'Import Error',
          message: 'Failed to import settings file',
          color: 'red'
        })
      }
    }
    reader.readAsText(file)
  }

  return (
    <div>
      <CustomerHeader 
        title="WhatsApp Settings"
        subtitle="Configure your WhatsApp integration settings and preferences"
        badge={{ label: 'Configuration', color: 'blue' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Device Selection & Save Controls */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>Settings Configuration</Title>
              <Group gap="sm">
                <Button
                  variant="light"
                  leftSection={<IconDownload size="1rem" />}
                  onClick={exportSettings}
                >
                  Export
                </Button>
                <input
                  type="file"
                  accept=".json"
                  style={{ display: 'none' }}
                  id="import-settings"
                  onChange={importSettings}
                />
                <Button
                  variant="light"
                  leftSection={<IconUpload size="1rem" />}
                  onClick={() => document.getElementById('import-settings')?.click()}
                >
                  Import
                </Button>
                <Button
                  variant="light"
                  color="red"
                  leftSection={<IconTrash size="1rem" />}
                  onClick={resetSettings}
                >
                  Reset
                </Button>
                <Button
                  leftSection={<IconCheck size="1rem" />}
                  onClick={saveSettings}
                  disabled={!unsavedChanges}
                >
                  Save Settings
                </Button>
              </Group>
            </Group>

            <Grid>
              <Grid.Col span={6}>
                <Select
                  label="Active Device"
                  placeholder="Select device for configuration"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'} - ${device.serverName}`
                  }))}
                  value={selectedDevice}
                  onChange={(value) => setSelectedDevice(value || '')}
                  leftSection={<IconDeviceMobile size="1rem" />}
                />
              </Grid.Col>
              <Grid.Col span={6}>
                {unsavedChanges && (
                  <Alert icon={<IconInfoCircle size="1rem" />} color="yellow" mt="xl">
                    <Text size="sm">You have unsaved changes</Text>
                  </Alert>
                )}
              </Grid.Col>
            </Grid>
          </Card>

          {/* Device Connection Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconDeviceMobile size="1.2rem" />
                Device Connection Settings
              </Group>
            </Title>
            
            <Grid>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Auto Reconnection"
                  description="Automatically reconnect when connection is lost"
                  checked={settings.autoReconnect}
                  onChange={(event) => updateSetting('autoReconnect', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <NumberInput
                  label="Connection Timeout (seconds)"
                  description="Maximum time to wait for connection"
                  value={settings.connectionTimeout}
                  onChange={(value) => updateSetting('connectionTimeout', value)}
                  min={10}
                  max={120}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <NumberInput
                  label="Max Retry Attempts"
                  description="Number of reconnection attempts"
                  value={settings.maxRetryAttempts}
                  onChange={(value) => updateSetting('maxRetryAttempts', value)}
                  min={1}
                  max={10}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <NumberInput
                  label="QR Code Timeout (seconds)"
                  description="How long QR code remains valid"
                  value={settings.qrCodeTimeout}
                  onChange={(value) => updateSetting('qrCodeTimeout', value)}
                  min={30}
                  max={300}
                />
              </Grid.Col>
            </Grid>
          </Card>

          {/* Message Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconMessage size="1.2rem" />
                Message Settings
              </Group>
            </Title>
            
            <Grid>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Select
                  label="Default Message Type"
                  data={[
                    { value: 'text', label: 'Text Messages' },
                    { value: 'image', label: 'Image Messages' },
                    { value: 'document', label: 'Document Messages' }
                  ]}
                  value={settings.defaultMessageType}
                  onChange={(value) => updateSetting('defaultMessageType', value)}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <NumberInput
                  label="Message Delay (seconds)"
                  description="Delay between consecutive messages"
                  value={settings.messageDelay}
                  onChange={(value) => updateSetting('messageDelay', value)}
                  min={1}
                  max={60}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Enable Read Receipts"
                  description="Show when messages are read"
                  checked={settings.enableReadReceipts}
                  onChange={(event) => updateSetting('enableReadReceipts', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Enable Typing Indicator"
                  description="Show typing indicator when composing"
                  checked={settings.enableTypingIndicator}
                  onChange={(event) => updateSetting('enableTypingIndicator', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <div>
                  <Text size="sm" fw={500} mb="xs">Maximum Message Length</Text>
                  <Slider
                    value={settings.maxMessageLength}
                    onChange={(value) => updateSetting('maxMessageLength', value)}
                    min={100}
                    max={4096}
                    step={100}
                    marks={[
                      { value: 100, label: '100' },
                      { value: 1000, label: '1K' },
                      { value: 2000, label: '2K' },
                      { value: 4096, label: '4K' }
                    ]}
                    color="green"
                  />
                  <Text size="xs" c="dimmed" mt="xs">
                    Current: {settings.maxMessageLength} characters
                  </Text>
                </div>
              </Grid.Col>
            </Grid>
          </Card>

          {/* Notification Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconBell size="1.2rem" />
                Notification Settings
              </Group>
            </Title>
            
            <Grid>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Enable Notifications"
                  description="Receive notifications for new messages"
                  checked={settings.enableNotifications}
                  onChange={(event) => updateSetting('enableNotifications', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Notification Sound"
                  description="Play sound for notifications"
                  checked={settings.notificationSound}
                  onChange={(event) => updateSetting('notificationSound', event.currentTarget.checked)}
                  disabled={!settings.enableNotifications}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Desktop Notifications"
                  description="Show browser notifications"
                  checked={settings.desktopNotifications}
                  onChange={(event) => updateSetting('desktopNotifications', event.currentTarget.checked)}
                  disabled={!settings.enableNotifications}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Email Notifications"
                  description="Send notifications via email"
                  checked={settings.emailNotifications}
                  onChange={(event) => updateSetting('emailNotifications', event.currentTarget.checked)}
                  disabled={!settings.enableNotifications}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <TextInput
                  label="Webhook URL (Optional)"
                  placeholder="https://your-webhook-url.com/webhook"
                  description="Receive notifications via webhook"
                  value={settings.webhookUrl}
                  onChange={(event) => updateSetting('webhookUrl', event.target.value)}
                />
              </Grid.Col>
            </Grid>
          </Card>

          {/* Security Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconShield size="1.2rem" />
                Security Settings
              </Group>
            </Title>
            
            <Grid>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Enable Encryption"
                  description="Encrypt sensitive data"
                  checked={settings.enableEncryption}
                  onChange={(event) => updateSetting('enableEncryption', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <NumberInput
                  label="Session Timeout (minutes)"
                  description="Auto-logout after inactivity"
                  value={settings.sessionTimeout}
                  onChange={(value) => updateSetting('sessionTimeout', value)}
                  min={15}
                  max={480}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <Switch
                  label="Two-Factor Authentication"
                  description="Enable 2FA for additional security"
                  checked={settings.twoFactorAuth}
                  onChange={(event) => updateSetting('twoFactorAuth', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <Textarea
                  label="IP Whitelist (Optional)"
                  placeholder="192.168.1.100&#10;10.0.0.50&#10;127.0.0.1"
                  description="One IP address per line. Leave empty to allow all IPs."
                  rows={4}
                  value={settings.ipWhitelist.join('\n')}
                  onChange={(event) => {
                    const ips = event.target.value.split('\n').filter(ip => ip.trim())
                    updateSetting('ipWhitelist', ips)
                  }}
                />
              </Grid.Col>
            </Grid>
          </Card>

          {/* Automation Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconClock size="1.2rem" />
                Automation Settings
              </Group>
            </Title>
            
            <Stack gap="md">
              <Switch
                label="Enable Auto Reply"
                description="Automatically respond to incoming messages"
                checked={settings.autoReply}
                onChange={(event) => updateSetting('autoReply', event.currentTarget.checked)}
              />
              
              {settings.autoReply && (
                <Textarea
                  label="Auto Reply Message"
                  placeholder="Thank you for your message..."
                  value={settings.autoReplyMessage}
                  onChange={(event) => updateSetting('autoReplyMessage', event.target.value)}
                  rows={3}
                />
              )}

              <Divider />

              <Switch
                label="Business Hours"
                description="Enable business hours restrictions"
                checked={settings.businessHours.enabled}
                onChange={(event) => updateNestedSetting('businessHours', 'enabled', event.currentTarget.checked)}
              />
              
              {settings.businessHours.enabled && (
                <Grid>
                  <Grid.Col span={4}>
                    <TextInput
                      label="Start Time"
                      type="time"
                      value={settings.businessHours.start}
                      onChange={(event) => updateNestedSetting('businessHours', 'start', event.target.value)}
                    />
                  </Grid.Col>
                  <Grid.Col span={4}>
                    <TextInput
                      label="End Time"
                      type="time"
                      value={settings.businessHours.end}
                      onChange={(event) => updateNestedSetting('businessHours', 'end', event.target.value)}
                    />
                  </Grid.Col>
                  <Grid.Col span={4}>
                    <Select
                      label="Timezone"
                      data={[
                        { value: 'Asia/Kolkata', label: 'Asia/Kolkata (IST)' },
                        { value: 'America/New_York', label: 'America/New_York (EST)' },
                        { value: 'Europe/London', label: 'Europe/London (GMT)' },
                        { value: 'Asia/Dubai', label: 'Asia/Dubai (UAE)' }
                      ]}
                      value={settings.businessHours.timezone}
                      onChange={(value) => updateNestedSetting('businessHours', 'timezone', value)}
                    />
                  </Grid.Col>
                </Grid>
              )}
            </Stack>
          </Card>

          {/* API Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconSettings size="1.2rem" />
                API Settings
              </Group>
            </Title>
            
            <Grid>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <NumberInput
                  label="Rate Limit (requests/minute)"
                  description="Maximum API requests per minute"
                  value={settings.rateLimitPerMinute}
                  onChange={(value) => updateSetting('rateLimitPerMinute', value)}
                  min={10}
                  max={1000}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <Switch
                  label="Enable API Logging"
                  description="Log API requests and responses"
                  checked={settings.enableApiLogging}
                  onChange={(event) => updateSetting('enableApiLogging', event.currentTarget.checked)}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <Select
                  label="Log Level"
                  description="Minimum log level to record"
                  data={[
                    { value: 'error', label: 'Error - Only errors' },
                    { value: 'warn', label: 'Warning - Warnings and errors' },
                    { value: 'info', label: 'Info - General information' },
                    { value: 'debug', label: 'Debug - Detailed debugging info' }
                  ]}
                  value={settings.logLevel}
                  onChange={(value) => updateSetting('logLevel', value)}
                />
              </Grid.Col>
            </Grid>
          </Card>

          {/* Appearance Settings */}
          <Card withBorder padding="lg">
            <Title order={5} mb="md">
              <Group gap="sm">
                <IconPalette size="1.2rem" />
                Appearance Settings
              </Group>
            </Title>
            
            <Grid>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <SegmentedControl
                  label="Theme"
                  data={[
                    { label: 'Light', value: 'light' },
                    { label: 'Dark', value: 'dark' },
                    { label: 'Auto', value: 'auto' }
                  ]}
                  value={settings.theme}
                  onChange={(value) => updateSetting('theme', value)}
                  fullWidth
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 6 }}>
                <ColorInput
                  label="Accent Color"
                  description="Primary theme color"
                  value={settings.accentColor}
                  onChange={(value) => updateSetting('accentColor', value)}
                  format="hex"
                  swatches={['#25D366', '#2196f3', '#9c27b0', '#f44336', '#ff9800', '#4caf50']}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <Switch
                  label="Compact Mode"
                  description="Use compact layout with smaller elements"
                  checked={settings.compactMode}
                  onChange={(event) => updateSetting('compactMode', event.currentTarget.checked)}
                />
              </Grid.Col>
            </Grid>
          </Card>

          {/* Save Warning */}
          {unsavedChanges && (
            <Alert icon={<IconInfoCircle size="1rem" />} color="yellow">
              <Group justify="space-between">
                <div>
                  <Text size="sm" fw={500}>You have unsaved changes</Text>
                  <Text size="xs">Make sure to save your settings before leaving this page.</Text>
                </div>
                <Button size="sm" onClick={saveSettings}>
                  Save Now
                </Button>
              </Group>
            </Alert>
          )}
        </Stack>
      </Container>
    </div>
  )
}