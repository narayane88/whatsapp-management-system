'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  TextInput,
  Select,
  Text,
  Title,
  Badge,
  Table,
  Pagination,
  ActionIcon,
  Modal,
  Alert,
  LoadingOverlay,
  Grid,
  Switch
} from '@mantine/core'
import {
  IconBrandWhatsapp,
  IconInbox,
  IconSearch,
  IconEye,
  IconRefresh,
  IconPhone,
  IconMessage,
  IconReply,
  IconPhoto,
  IconFile,
  IconVideo,
  IconMusic,
  IconMapPin,
  IconUser,
  IconClock
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import { useDisclosure } from '@mantine/hooks'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface ReceivedMessage {
  id: string
  deviceId: string
  deviceName: string
  sender: string
  senderName?: string
  message: string
  messageType: 'text' | 'image' | 'document' | 'video' | 'audio' | 'location'
  attachmentUrl?: string
  receivedAt: string
  isRead: boolean
  isGroup: boolean
  groupName?: string
  messageId: string
  isForwarded?: boolean
  quotedMessage?: string
}

interface ConnectedDevice {
  id: string
  accountName: string
  phoneNumber?: string
  status: string
  serverName: string
}

export default function ReceivedMessagesPage() {
  const [messages, setMessages] = useState<ReceivedMessage[]>([])
  const [devices, setDevices] = useState<ConnectedDevice[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDevice, setFilterDevice] = useState('')
  const [filterType, setFilterType] = useState('')
  const [showUnreadOnly, setShowUnreadOnly] = useState(false)
  const [showGroupsOnly, setShowGroupsOnly] = useState(false)
  const [dateRange, setDateRange] = useState('today')
  const [selectedMessage, setSelectedMessage] = useState<ReceivedMessage | null>(null)
  const [detailsOpened, { open: openDetails, close: closeDetails }] = useDisclosure(false)

  useEffect(() => {
    fetchDevices()
    fetchReceivedMessages()
  }, [currentPage, filterDevice, filterType, showUnreadOnly, showGroupsOnly, dateRange, searchTerm])

  const fetchDevices = async () => {
    try {
      const response = await fetch('/api/customer/host/connections')
      if (response.ok) {
        const allDevices = await response.json()
        setDevices(allDevices)
      }
    } catch (error) {
      console.error('Error fetching devices:', error)
    }
  }

  const fetchReceivedMessages = async () => {
    try {
      setLoading(true)
      
      const params = new URLSearchParams({
        userId: '1', // TODO: Get from auth context
        page: currentPage.toString(),
        limit: '20'
      })

      if (filterDevice) params.append('deviceId', filterDevice)
      if (filterType) params.append('messageType', filterType)
      if (showUnreadOnly) params.append('unreadOnly', 'true')
      if (showGroupsOnly) params.append('groupsOnly', 'true')
      if (searchTerm) params.append('search', searchTerm)
      if (dateRange !== 'all') params.append('dateRange', dateRange)

      const response = await fetch(`/api/customer/whatsapp/received?${params.toString()}`)
      const result = await response.json()

      if (response.ok) {
        // Map API response to component interface
        const mappedMessages: ReceivedMessage[] = (result.messages || []).map((msg: any) => ({
          id: msg.id.toString(),
          deviceId: msg.instance_id,
          deviceName: msg.instance_name || 'Unknown Device',
          sender: msg.from_number,
          senderName: msg.sender_name,
          message: msg.message_content,
          messageType: msg.message_type as any,
          attachmentUrl: msg.attachment_url,
          receivedAt: msg.received_at,
          isRead: msg.is_read,
          isGroup: msg.is_group_message,
          groupName: msg.group_name,
          messageId: msg.whatsapp_message_id,
          isForwarded: msg.is_forwarded,
          quotedMessage: msg.quoted_message
        }))

        setMessages(mappedMessages)
        setTotalPages(result.pagination?.totalPages || 1)
      } else {
        throw new Error(result.error || 'Failed to fetch received messages')
      }
    } catch (error) {
      console.error('Error fetching received messages:', error)
      notifications.show({
        title: 'Error',
        message: 'Failed to load received messages',
        color: 'red'
      })
      // Fallback to empty array on error
      setMessages([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case 'image': return <IconPhoto size="1rem" color="#9c27b0" />
      case 'document': return <IconFile size="1rem" color="#2196f3" />
      case 'video': return <IconVideo size="1rem" color="#f44336" />
      case 'audio': return <IconMusic size="1rem" color="#ff9800" />
      case 'location': return <IconMapPin size="1rem" color="#4caf50" />
      default: return <IconMessage size="1rem" color="#607d8b" />
    }
  }

  const markAsRead = async (messageId: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, isRead: true } : msg
    ))
    
    notifications.show({
      title: 'Message marked as read',
      message: 'Message status updated',
      color: 'green'
    })
  }

  const replyToMessage = (message: ReceivedMessage) => {
    // Navigate to send page with pre-filled recipient
    const recipient = message.sender
    const replyText = `Reply to: "${message.message.substring(0, 50)}${message.message.length > 50 ? '...' : ''}"`
    
    notifications.show({
      title: 'Reply Feature',
      message: `Reply to ${message.senderName || message.sender}`,
      color: 'blue'
    })
    
    // In a real implementation, you would navigate to the send page with pre-filled data
    // router.push(`/customer/whatsapp/send?recipient=${recipient}&replyTo=${message.id}`)
  }

  const viewMessageDetails = (message: ReceivedMessage) => {
    if (!message.isRead) {
      markAsRead(message.id)
    }
    setSelectedMessage(message)
    openDetails()
  }

  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.sender.includes(searchTerm) ||
                         (message.senderName?.toLowerCase().includes(searchTerm.toLowerCase())) ||
                         (message.groupName?.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesDevice = !filterDevice || message.deviceId === filterDevice
    const matchesType = !filterType || message.messageType === filterType
    const matchesUnread = !showUnreadOnly || !message.isRead
    const matchesGroup = !showGroupsOnly || message.isGroup

    return matchesSearch && matchesDevice && matchesType && matchesUnread && matchesGroup
  })

  const getMessageStats = () => {
    const total = messages.length
    const unread = messages.filter(m => !m.isRead).length
    const groups = messages.filter(m => m.isGroup).length
    const individual = messages.filter(m => !m.isGroup).length

    return { total, unread, groups, individual }
  }

  const stats = getMessageStats()

  if (loading) {
    return <LoadingOverlay visible />
  }

  return (
    <div>
      <CustomerHeader 
        title="Received Messages"
        subtitle="View and manage incoming WhatsApp messages from customers and groups"
        badge={{ label: 'Inbox', color: 'blue' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Stats Cards */}
          <Grid>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#f8f9fa' }}>
                <Group gap="sm">
                  <IconInbox size={20} color="#2196f3" />
                  <div>
                    <Text size="xs" c="dimmed">Total Received</Text>
                    <Text size="lg" fw={600}>{stats.total}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#fff3cd' }}>
                <Group gap="sm">
                  <IconClock size={20} color="#ff9800" />
                  <div>
                    <Text size="xs" c="dimmed">Unread</Text>
                    <Text size="lg" fw={600} c="orange">{stats.unread}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#e8f5e8' }}>
                <Group gap="sm">
                  <IconUser size={20} color="#4caf50" />
                  <div>
                    <Text size="xs" c="dimmed">Individual</Text>
                    <Text size="lg" fw={600}>{stats.individual}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
            <Grid.Col span={{ base: 6, md: 3 }}>
              <Card withBorder padding="md" style={{ backgroundColor: '#f3e5f5' }}>
                <Group gap="sm">
                  <IconBrandWhatsapp size={20} color="#9c27b0" />
                  <div>
                    <Text size="xs" c="dimmed">Groups</Text>
                    <Text size="lg" fw={600}>{stats.groups}</Text>
                  </div>
                </Group>
              </Card>
            </Grid.Col>
          </Grid>

          {/* Filters */}
          <Card withBorder padding="lg">
            <Title order={4} mb="md">Filter Messages</Title>
            <Grid>
              <Grid.Col span={{ base: 12, md: 3 }}>
                <TextInput
                  placeholder="Search messages, senders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  leftSection={<IconSearch size="1rem" />}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Filter by device"
                  data={devices.map(device => ({
                    value: device.id,
                    label: `${device.phoneNumber ? `(${device.phoneNumber})` : 'No Phone'}`
                  }))}
                  value={filterDevice}
                  onChange={(value) => setFilterDevice(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Message type"
                  data={[
                    { value: 'text', label: 'Text' },
                    { value: 'image', label: 'Image' },
                    { value: 'document', label: 'Document' },
                    { value: 'video', label: 'Video' },
                    { value: 'audio', label: 'Audio' },
                    { value: 'location', label: 'Location' }
                  ]}
                  value={filterType}
                  onChange={(value) => setFilterType(value || '')}
                  clearable
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 2 }}>
                <Select
                  placeholder="Date range"
                  data={[
                    { value: 'today', label: 'Today' },
                    { value: 'week', label: 'This Week' },
                    { value: 'month', label: 'This Month' },
                    { value: 'all', label: 'All Time' }
                  ]}
                  value={dateRange}
                  onChange={(value) => setDateRange(value || 'today')}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 6, md: 1.5 }}>
                <Switch
                  label="Unread only"
                  checked={showUnreadOnly}
                  onChange={(event) => setShowUnreadOnly(event.currentTarget.checked)}
                  size="sm"
                />
              </Grid.Col>
              <Grid.Col span={{ base: 6, md: 1.5 }}>
                <Switch
                  label="Groups only"
                  checked={showGroupsOnly}
                  onChange={(event) => setShowGroupsOnly(event.currentTarget.checked)}
                  size="sm"
                />
              </Grid.Col>
            </Grid>
            
            <Group justify="flex-end" mt="md">
              <Button
                variant="light"
                onClick={fetchReceivedMessages}
                leftSection={<IconRefresh size="1rem" />}
              >
                Refresh
              </Button>
            </Group>
          </Card>

          {/* Messages Table */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={4}>Received Messages ({filteredMessages.length})</Title>
            </Group>

            {filteredMessages.length > 0 ? (
              <>
                <Table striped highlightOnHover>
                  <Table.Thead>
                    <Table.Tr>
                      <Table.Th>Status</Table.Th>
                      <Table.Th>Type</Table.Th>
                      <Table.Th>Sender</Table.Th>
                      <Table.Th>Message</Table.Th>
                      <Table.Th>Source</Table.Th>
                      <Table.Th>Device</Table.Th>
                      <Table.Th>Received At</Table.Th>
                      <Table.Th>Actions</Table.Th>
                    </Table.Tr>
                  </Table.Thead>
                  <Table.Tbody>
                    {filteredMessages.map((message) => (
                      <Table.Tr 
                        key={message.id} 
                        style={{ 
                          backgroundColor: message.isRead ? undefined : '#fff8e1',
                          fontWeight: message.isRead ? 'normal' : 500
                        }}
                      >
                        <Table.Td>
                          {!message.isRead && (
                            <Badge size="xs" color="orange" variant="filled">
                              NEW
                            </Badge>
                          )}
                          {message.isForwarded && (
                            <Badge size="xs" color="blue" variant="light" ml="xs">
                              FWD
                            </Badge>
                          )}
                        </Table.Td>
                        <Table.Td>
                          <Group gap="xs">
                            {getMessageTypeIcon(message.messageType)}
                            <Text size="xs" tt="capitalize">{message.messageType}</Text>
                          </Group>
                        </Table.Td>
                        <Table.Td>
                          <div>
                            <Text size="sm" fw={500}>
                              {message.senderName || message.sender}
                            </Text>
                            {message.senderName && (
                              <Text size="xs" c="dimmed">{message.sender}</Text>
                            )}
                          </div>
                        </Table.Td>
                        <Table.Td>
                          <Text size="sm" lineClamp={2} style={{ maxWidth: 200 }}>
                            {message.messageType === 'text' ? message.message : 
                             `[${message.messageType.toUpperCase()}] ${message.message}`}
                          </Text>
                        </Table.Td>
                        <Table.Td>
                          <div>
                            <Badge 
                              size="xs" 
                              color={message.isGroup ? 'grape' : 'teal'}
                              variant="light"
                            >
                              {message.isGroup ? 'Group' : 'Individual'}
                            </Badge>
                            {message.groupName && (
                              <Text size="xs" c="dimmed" mt={2}>
                                {message.groupName}
                              </Text>
                            )}
                          </div>
                        </Table.Td>
                        <Table.Td>
                          <Text size="xs" c="dimmed">{message.deviceName}</Text>
                        </Table.Td>
                        <Table.Td>
                          <Text size="xs">
                            {new Date(message.receivedAt).toLocaleString()}
                          </Text>
                        </Table.Td>
                        <Table.Td>
                          <Group gap="xs">
                            <ActionIcon
                              variant="subtle"
                              color="blue"
                              onClick={() => viewMessageDetails(message)}
                              title="View Details"
                            >
                              <IconEye size="1rem" />
                            </ActionIcon>
                            <ActionIcon
                              variant="subtle"
                              color="green"
                              onClick={() => replyToMessage(message)}
                              title="Reply"
                            >
                              <IconReply size="1rem" />
                            </ActionIcon>
                          </Group>
                        </Table.Td>
                      </Table.Tr>
                    ))}
                  </Table.Tbody>
                </Table>

                {totalPages > 1 && (
                  <Group justify="center" mt="md">
                    <Pagination 
                      total={totalPages} 
                      value={currentPage} 
                      onChange={setCurrentPage}
                    />
                  </Group>
                )}
              </>
            ) : (
              <Alert color="blue">
                <Text size="sm" fw={500}>No received messages found</Text>
                <Text size="xs">
                  {searchTerm || filterDevice || filterType || showUnreadOnly || showGroupsOnly ? 
                    'Try adjusting your filters or search terms.' : 
                    'No messages have been received yet.'}
                </Text>
              </Alert>
            )}
          </Card>

          {/* Message Details Modal */}
          <Modal
            opened={detailsOpened}
            onClose={closeDetails}
            title="Message Details"
            size="lg"
          >
            {selectedMessage && (
              <Stack gap="md">
                <Group gap="md">
                  <Badge color={selectedMessage.isGroup ? 'grape' : 'teal'} size="lg">
                    {selectedMessage.isGroup ? 'Group Message' : 'Individual Message'}
                  </Badge>
                  <Badge variant="light">
                    {selectedMessage.messageType.toUpperCase()}
                  </Badge>
                  {selectedMessage.isForwarded && (
                    <Badge color="blue" variant="light">
                      FORWARDED
                    </Badge>
                  )}
                  {!selectedMessage.isRead && (
                    <Badge color="orange" variant="filled">
                      UNREAD
                    </Badge>
                  )}
                </Group>

                <Grid>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>From:</Text>
                    <Text size="sm">{selectedMessage.senderName || selectedMessage.sender}</Text>
                    {selectedMessage.senderName && (
                      <Text size="xs" c="dimmed">{selectedMessage.sender}</Text>
                    )}
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text size="sm" fw={500}>Device:</Text>
                    <Text size="sm">{selectedMessage.deviceName}</Text>
                  </Grid.Col>
                </Grid>

                {selectedMessage.isGroup && selectedMessage.groupName && (
                  <div>
                    <Text size="sm" fw={500}>Group:</Text>
                    <Text size="sm">{selectedMessage.groupName}</Text>
                  </div>
                )}

                <div>
                  <Text size="sm" fw={500} mb="xs">Message:</Text>
                  <Text 
                    size="sm" 
                    style={{ 
                      backgroundColor: '#f8f9fa', 
                      padding: '12px', 
                      borderRadius: '8px',
                      border: '1px solid #e9ecef'
                    }}
                  >
                    {selectedMessage.message}
                  </Text>
                </div>

                {selectedMessage.attachmentUrl && (
                  <div>
                    <Text size="sm" fw={500} mb="xs">Attachment:</Text>
                    <Text size="sm" c="blue" style={{ wordBreak: 'break-all' }}>
                      {selectedMessage.attachmentUrl}
                    </Text>
                  </div>
                )}

                <div>
                  <Text size="sm" fw={500}>Received:</Text>
                  <Text size="sm">{new Date(selectedMessage.receivedAt).toLocaleString()}</Text>
                </div>

                <div>
                  <Text size="sm" fw={500}>Message ID:</Text>
                  <Text size="xs" family="monospace" c="dimmed">{selectedMessage.messageId}</Text>
                </div>

                <Group justify="flex-end" mt="md">
                  {!selectedMessage.isRead && (
                    <Button
                      size="sm"
                      variant="light"
                      onClick={() => markAsRead(selectedMessage.id)}
                    >
                      Mark as Read
                    </Button>
                  )}
                  <Button
                    size="sm"
                    leftSection={<IconReply size="1rem" />}
                    onClick={() => replyToMessage(selectedMessage)}
                  >
                    Reply
                  </Button>
                </Group>
              </Stack>
            )}
          </Modal>
        </Stack>
      </Container>
    </div>
  )
}