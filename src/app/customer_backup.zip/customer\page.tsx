import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import CustomerHeader from '@/components/customer/CustomerHeader'
import CustomerDashboard from '@/components/customer/CustomerDashboard'

export default async function CustomerPage() {
  const session = await getServerSession(authOptions)
  
  return (
    <div>
      <CustomerHeader 
        title={`Welcome, ${session?.user?.name || 'Customer'}`}
        subtitle="Manage your WhatsApp business communications"
      />
      <CustomerDashboard />
    </div>
  )
}