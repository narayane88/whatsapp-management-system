'use client'

import { useState, useEffect } from 'react'
import {
  Container,
  Card,
  Stack,
  Group,
  Button,
  Text,
  Title,
  Badge,
  LoadingOverlay,
  Alert,
  Select,
  ActionIcon,
  Table,
  Tooltip,
  Modal,
  Textarea
} from '@mantine/core'
import {
  IconRefresh,
  IconTrash,
  IconPause,
  IconPlay,
  IconEye,
  IconMessage,
  IconPhoto,
  IconFile,
  IconVideo,
  IconMusic,
  IconMapPin,
  IconClock,
  IconX,
  IconCheck,
  IconAlertCircle
} from '@tabler/icons-react'
import { notifications } from '@mantine/notifications'
import CustomerHeader from '@/components/customer/CustomerHeader'

interface QueueMessage {
  id: number
  to_number: string
  message: string
  message_type: string
  attachment_url?: string
  status: string
  priority: number
  instance_id: string
  instance_name: string
  scheduled_at?: string
  created_at: string
  updated_at: string
  sent_at?: string
  error_message?: string
  retry_count: number
  max_retries: number
  metadata?: any
}

interface QueueStats {
  totalMessages: number
  pendingMessages: number
  processingMessages: number
  sentMessages: number
  failedMessages: number
}

export default function MessageQueuePage() {
  const [messages, setMessages] = useState<QueueMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [stats, setStats] = useState<QueueStats>({
    totalMessages: 0,
    pendingMessages: 0,
    processingMessages: 0,
    sentMessages: 0,
    failedMessages: 0
  })
  const [statusFilter, setStatusFilter] = useState<string>('')
  const [priorityFilter, setPriorityFilter] = useState<string>('')
  const [viewModalOpen, setViewModalOpen] = useState(false)
  const [selectedMessage, setSelectedMessage] = useState<QueueMessage | null>(null)

  useEffect(() => {
    fetchQueueMessages()
  }, [statusFilter, priorityFilter])

  const fetchQueueMessages = async (showLoading = true) => {
    try {
      if (showLoading) setLoading(true)
      else setRefreshing(true)

      const params = new URLSearchParams({
        userId: '1' // TODO: Get from auth context
      })

      if (statusFilter) params.append('status', statusFilter)
      if (priorityFilter) params.append('priority', priorityFilter)

      const response = await fetch(`/api/customer/whatsapp/queue?${params.toString()}`)
      const result = await response.json()

      if (response.ok) {
        setMessages(result.messages || [])
        setStats(result.statistics || {
          totalMessages: 0,
          pendingMessages: 0,
          processingMessages: 0,
          sentMessages: 0,
          failedMessages: 0
        })
      } else {
        throw new Error(result.error || 'Failed to fetch queue messages')
      }
    } catch (error) {
      console.error('Error fetching queue messages:', error)
      notifications.show({
        title: 'Error',
        message: 'Failed to fetch queue messages',
        color: 'red'
      })
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const updateMessageStatus = async (messageId: number, newStatus: string) => {
    try {
      const response = await fetch('/api/customer/whatsapp/queue', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messageId,
          userId: 1, // TODO: Get from auth context
          status: newStatus
        })
      })

      const result = await response.json()

      if (response.ok) {
        notifications.show({
          title: 'Status Updated',
          message: `Message status changed to ${newStatus}`,
          color: 'green'
        })
        fetchQueueMessages(false)
      } else {
        throw new Error(result.error || 'Failed to update status')
      }
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to update message status',
        color: 'red'
      })
    }
  }

  const deleteMessage = async (messageId: number) => {
    try {
      const response = await fetch(`/api/customer/whatsapp/queue?messageId=${messageId}&userId=1`, {
        method: 'DELETE'
      })

      const result = await response.json()

      if (response.ok) {
        notifications.show({
          title: 'Message Deleted',
          message: 'Message removed from queue',
          color: 'green'
        })
        fetchQueueMessages(false)
      } else {
        throw new Error(result.error || 'Failed to delete message')
      }
    } catch (error) {
      notifications.show({
        title: 'Error',
        message: 'Failed to delete message',
        color: 'red'
      })
    }
  }

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case 'text': return <IconMessage size="1rem" />
      case 'image': return <IconPhoto size="1rem" />
      case 'document': return <IconFile size="1rem" />
      case 'video': return <IconVideo size="1rem" />
      case 'audio': return <IconMusic size="1rem" />
      case 'location': return <IconMapPin size="1rem" />
      default: return <IconMessage size="1rem" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'blue'
      case 'processing': return 'orange'
      case 'sent': return 'green'
      case 'failed': return 'red'
      case 'paused': return 'gray'
      default: return 'gray'
    }
  }

  const getPriorityLabel = (priority: number) => {
    switch (priority) {
      case 0: return 'Normal'
      case 1: return 'High'
      case 2: return 'Urgent'
      default: return 'Normal'
    }
  }

  const getPriorityColor = (priority: number) => {
    switch (priority) {
      case 0: return 'blue'
      case 1: return 'orange'
      case 2: return 'red'
      default: return 'blue'
    }
  }

  const formatMessageContent = (message: QueueMessage) => {
    if (message.message_type === 'text') {
      return message.message.length > 50 ? message.message.substring(0, 50) + '...' : message.message
    }
    return `[${message.message_type.toUpperCase()}] ${message.message}`
  }

  if (loading) {
    return <LoadingOverlay visible />
  }

  return (
    <div>
      <CustomerHeader 
        title="Message Queue"
        subtitle="Manage pending and scheduled messages"
        badge={{ label: 'Real-time', color: 'green' }}
      />
      
      <Container size="xl" py="md">
        <Stack gap="lg">
          {/* Statistics Cards */}
          <Group grow>
            <Card withBorder padding="md" style={{ backgroundColor: '#e3f2fd' }}>
              <Group justify="space-between">
                <div>
                  <Text size="xs" c="dimmed" tt="uppercase" fw={700}>Total Messages</Text>
                  <Text size="xl" fw={700}>{stats.totalMessages}</Text>
                </div>
                <IconMessage size={24} color="#1976d2" />
              </Group>
            </Card>
            
            <Card withBorder padding="md" style={{ backgroundColor: '#fff3e0' }}>
              <Group justify="space-between">
                <div>
                  <Text size="xs" c="dimmed" tt="uppercase" fw={700}>Pending</Text>
                  <Text size="xl" fw={700}>{stats.pendingMessages}</Text>
                </div>
                <IconClock size={24} color="#f57c00" />
              </Group>
            </Card>
            
            <Card withBorder padding="md" style={{ backgroundColor: '#e8f5e8' }}>
              <Group justify="space-between">
                <div>
                  <Text size="xs" c="dimmed" tt="uppercase" fw={700}>Sent</Text>
                  <Text size="xl" fw={700}>{stats.sentMessages}</Text>
                </div>
                <IconCheck size={24} color="#388e3c" />
              </Group>
            </Card>
            
            <Card withBorder padding="md" style={{ backgroundColor: '#ffebee' }}>
              <Group justify="space-between">
                <div>
                  <Text size="xs" c="dimmed" tt="uppercase" fw={700}>Failed</Text>
                  <Text size="xl" fw={700}>{stats.failedMessages}</Text>
                </div>
                <IconX size={24} color="#d32f2f" />
              </Group>
            </Card>
          </Group>

          {/* Controls */}
          <Card withBorder padding="lg">
            <Group justify="space-between" mb="md">
              <Title order={3}>Queue Management</Title>
              <Group gap="sm">
                <Button
                  variant="light"
                  leftSection={<IconRefresh size="1rem" />}
                  onClick={() => fetchQueueMessages(false)}
                  loading={refreshing}
                  size="sm"
                >
                  Refresh
                </Button>
              </Group>
            </Group>
            
            <Group gap="md" mb="md">
              <Select
                placeholder="Filter by Status"
                data={[
                  { value: '', label: 'All Statuses' },
                  { value: 'pending', label: 'Pending' },
                  { value: 'processing', label: 'Processing' },
                  { value: 'sent', label: 'Sent' },
                  { value: 'failed', label: 'Failed' },
                  { value: 'paused', label: 'Paused' }
                ]}
                value={statusFilter}
                onChange={(value) => setStatusFilter(value || '')}
                clearable
                style={{ minWidth: 150 }}
              />
              
              <Select
                placeholder="Filter by Priority"
                data={[
                  { value: '', label: 'All Priorities' },
                  { value: '0', label: 'Normal' },
                  { value: '1', label: 'High' },
                  { value: '2', label: 'Urgent' }
                ]}
                value={priorityFilter}
                onChange={(value) => setPriorityFilter(value || '')}
                clearable
                style={{ minWidth: 150 }}
              />
            </Group>

            {/* Messages Table */}
            {messages.length > 0 ? (
              <Table striped highlightOnHover>
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>Type</Table.Th>
                    <Table.Th>To</Table.Th>
                    <Table.Th>Content</Table.Th>
                    <Table.Th>Status</Table.Th>
                    <Table.Th>Priority</Table.Th>
                    <Table.Th>Instance</Table.Th>
                    <Table.Th>Scheduled</Table.Th>
                    <Table.Th>Actions</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>
                  {messages.map((message) => (
                    <Table.Tr key={message.id}>
                      <Table.Td>
                        <Group gap="xs">
                          {getMessageTypeIcon(message.message_type)}
                          <Text size="sm">{message.message_type}</Text>
                        </Group>
                      </Table.Td>
                      <Table.Td>
                        <Text size="sm">{message.to_number}</Text>
                      </Table.Td>
                      <Table.Td>
                        <Text size="sm" lineClamp={2}>
                          {formatMessageContent(message)}
                        </Text>
                      </Table.Td>
                      <Table.Td>
                        <Badge color={getStatusColor(message.status)} size="sm">
                          {message.status}
                        </Badge>
                        {message.error_message && (
                          <Tooltip label={message.error_message}>
                            <IconAlertCircle size={16} color="red" style={{ marginLeft: 4 }} />
                          </Tooltip>
                        )}
                      </Table.Td>
                      <Table.Td>
                        <Badge color={getPriorityColor(message.priority)} size="sm">
                          {getPriorityLabel(message.priority)}
                        </Badge>
                      </Table.Td>
                      <Table.Td>
                        <Text size="sm">{message.instance_name}</Text>
                      </Table.Td>
                      <Table.Td>
                        <Text size="sm">
                          {message.scheduled_at 
                            ? new Date(message.scheduled_at).toLocaleString()
                            : 'Immediate'
                          }
                        </Text>
                      </Table.Td>
                      <Table.Td>
                        <Group gap="xs">
                          <ActionIcon
                            size="sm"
                            variant="subtle"
                            onClick={() => {
                              setSelectedMessage(message)
                              setViewModalOpen(true)
                            }}
                          >
                            <IconEye size={14} />
                          </ActionIcon>
                          
                          {message.status === 'pending' && (
                            <ActionIcon
                              size="sm"
                              variant="subtle"
                              color="orange"
                              onClick={() => updateMessageStatus(message.id, 'paused')}
                            >
                              <IconPause size={14} />
                            </ActionIcon>
                          )}
                          
                          {message.status === 'paused' && (
                            <ActionIcon
                              size="sm"
                              variant="subtle"
                              color="green"
                              onClick={() => updateMessageStatus(message.id, 'pending')}
                            >
                              <IconPlay size={14} />
                            </ActionIcon>
                          )}
                          
                          {(message.status === 'failed' || message.status === 'paused') && (
                            <ActionIcon
                              size="sm"
                              variant="subtle"
                              color="red"
                              onClick={() => deleteMessage(message.id)}
                            >
                              <IconTrash size={14} />
                            </ActionIcon>
                          )}
                        </Group>
                      </Table.Td>
                    </Table.Tr>
                  ))}
                </Table.Tbody>
              </Table>
            ) : (
              <Alert icon={<IconMessage size="1rem" />} color="blue">
                <Text size="sm" fw={500}>No messages in queue</Text>
                <Text size="xs">
                  Add messages to the queue from the "Send Messages" page or they will appear here as they're processed.
                </Text>
              </Alert>
            )}
          </Card>
        </Stack>
      </Container>

      {/* Message Details Modal */}
      <Modal
        opened={viewModalOpen}
        onClose={() => setViewModalOpen(false)}
        title="Message Details"
        size="md"
      >
        {selectedMessage && (
          <Stack gap="sm">
            <Group justify="space-between">
              <Text fw={500}>Message ID:</Text>
              <Text>{selectedMessage.id}</Text>
            </Group>
            <Group justify="space-between">
              <Text fw={500}>Type:</Text>
              <Group gap="xs">
                {getMessageTypeIcon(selectedMessage.message_type)}
                <Text>{selectedMessage.message_type}</Text>
              </Group>
            </Group>
            <Group justify="space-between">
              <Text fw={500}>To:</Text>
              <Text>{selectedMessage.to_number}</Text>
            </Group>
            <Group justify="space-between">
              <Text fw={500}>Status:</Text>
              <Badge color={getStatusColor(selectedMessage.status)}>
                {selectedMessage.status}
              </Badge>
            </Group>
            <Group justify="space-between">
              <Text fw={500}>Priority:</Text>
              <Badge color={getPriorityColor(selectedMessage.priority)}>
                {getPriorityLabel(selectedMessage.priority)}
              </Badge>
            </Group>
            <Group justify="space-between">
              <Text fw={500}>Instance:</Text>
              <Text>{selectedMessage.instance_name}</Text>
            </Group>
            <div>
              <Text fw={500} mb="xs">Message Content:</Text>
              <Textarea
                value={selectedMessage.message}
                readOnly
                autosize
                minRows={3}
                maxRows={8}
              />
            </div>
            {selectedMessage.attachment_url && (
              <Group justify="space-between">
                <Text fw={500}>Attachment:</Text>
                <Text size="sm" c="blue" style={{ wordBreak: 'break-all' }}>
                  {selectedMessage.attachment_url}
                </Text>
              </Group>
            )}
            {selectedMessage.scheduled_at && (
              <Group justify="space-between">
                <Text fw={500}>Scheduled For:</Text>
                <Text>{new Date(selectedMessage.scheduled_at).toLocaleString()}</Text>
              </Group>
            )}
            <Group justify="space-between">
              <Text fw={500}>Created:</Text>
              <Text>{new Date(selectedMessage.created_at).toLocaleString()}</Text>
            </Group>
            {selectedMessage.sent_at && (
              <Group justify="space-between">
                <Text fw={500}>Sent At:</Text>
                <Text>{new Date(selectedMessage.sent_at).toLocaleString()}</Text>
              </Group>
            )}
            {selectedMessage.error_message && (
              <div>
                <Text fw={500} mb="xs" c="red">Error Message:</Text>
                <Alert icon={<IconAlertCircle size="1rem" />} color="red">
                  <Text size="sm">{selectedMessage.error_message}</Text>
                </Alert>
              </div>
            )}
            <Group justify="space-between">
              <Text fw={500}>Retry Count:</Text>
              <Text>{selectedMessage.retry_count} / {selectedMessage.max_retries}</Text>
            </Group>
          </Stack>
        )}
      </Modal>
    </div>
  )
}